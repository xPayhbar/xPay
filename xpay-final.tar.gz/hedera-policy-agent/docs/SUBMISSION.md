# Bounty Submission — Week 5: xPay

Copy the fields below into the submission form at https://ai-bounties.hedera.com/#submit

---

## Project name
xPay

## Project description (1–2 lines)
An AI payment agent that enforces runtime policies — spend limits, counterparty allowlists, and human-in-the-loop approval gates — before executing HBAR or USDC transfers on Hedera.

## Project summary (1–3 paragraphs)

The xPay is a full-stack AI agent built on the Hedera Agent Kit that enables autonomous on-chain payments while enforcing configurable runtime policies at every step. The agent accepts natural-language payment instructions ("Pay 50 HBAR to OpenAI for API credits") and runs each request through a policy engine before any funds move.

The policy layer consists of four composable hooks: a daily **spend limit** tracker (separate caps for HBAR and USDC with 24-hour rolling windows), a **counterparty allowlist** that rejects payments to non-approved Hedera accounts, a **human approval threshold** that pauses high-value transfers for explicit sign-off, and an **anomaly detector** that flags unknown recipients and suspicious round-number amounts. Policies are configured at runtime via a React UI — toggleable, adjustable with sliders, and applied instantly without redeploying.

Practical use cases demonstrated include paying OpenAI, Pinecone DB, Twilio, and IPFS APIs in HBAR or USDC, with the policy layer clearly blocking, flagging, or approving each transfer in real time. A human-in-the-loop modal appears for high-value transfers, letting an operator approve or reject before any on-chain execution. The full transaction ledger, spend meter, and per-policy violation details are surfaced in the UI so the policy enforcement is always visible and auditable.

## Implementation details

Built with:
- **Hedera Agent Kit JS v3.8.x** — `HederaLangchainToolkit` + `AgentMode.AUTONOMOUS` for on-chain HBAR transfers via `TransferTransaction`
- **LangChain + LangGraph** — `createReactAgent` with a custom `transfer_payment` tool that runs the policy engine before any execution
- **Claude (Anthropic)** via `@langchain/anthropic` as the LLM backbone
- **Policy hooks** — four independent TypeScript modules (`spendLimitHook`, `allowlistHook`, `approvalHook`, `anomalyHook`) each exporting a pure function called by the central `policyEngine.ts`
- **Express REST API** — `/api/chat`, `/api/approve/:id`, `/api/reject/:id`, `/api/spend` endpoints
- **React + Vite** frontend — real-time policy config panel, chat interface with inline policy event banners, transaction ledger, and human-in-the-loop modal

The policy engine runs hooks in priority order (allowlist → anomaly → approval → spend limit), collects all violations, and derives `approved | blocked | needs_approval`. Approved transfers execute on-chain and update the rolling spend state. The design ensures it is structurally impossible for the agent to move funds without passing every active policy.

## Feedback link
https://github.com/hashgraph/hedera-agent-kit-js/issues/new?template=agent_kit_feedback.yml

(Submit feedback after opening the link — the bounty requires one feedback issue filed)
