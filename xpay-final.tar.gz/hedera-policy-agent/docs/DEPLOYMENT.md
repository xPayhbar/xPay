# Deployment Guide

This guide covers deploying the xPay to three platforms:
**Railway** (easiest), **Render**, and **Fly.io**.

All platforms require these environment variables:

```
HEDERA_ACCOUNT_ID=0.0.XXXXX
HEDERA_PRIVATE_KEY=0x...
HEDERA_NETWORK=testnet
ANTHROPIC_API_KEY=sk-ant-...
NODE_ENV=production
PORT=3001
```

---

## Option A — Railway (Recommended, fastest)

1. Push your repo to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Select your `xpay` repository
4. Railway auto-detects the Dockerfile — click **Deploy**
5. Go to Settings → Variables → add all env vars above
6. Go to Settings → Networking → Generate Domain
7. Your live URL is ready — submit it as your demo URL ✓

---

## Option B — Render

1. Push repo to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Set:
   - **Environment**: Docker
   - **Dockerfile path**: `./Dockerfile`
   - **Port**: `3001`
5. Add all environment variables in the Environment tab
6. Click **Create Web Service**
7. Copy the `.onrender.com` URL for your submission ✓

---

## Option C — Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Launch (first time)
fly launch --name xpay --region iad

# Set secrets
fly secrets set \
  HEDERA_ACCOUNT_ID="0.0.XXXXX" \
  HEDERA_PRIVATE_KEY="0x..." \
  HEDERA_NETWORK="testnet" \
  ANTHROPIC_API_KEY="sk-ant-..." \
  NODE_ENV="production"

# Deploy
fly deploy

# Get URL
fly open
```

---

## Local Development

```bash
# 1. Clone and install
git clone https://github.com/YOUR_USERNAME/xpay
cd xpay
npm install
cd frontend && npm install && cd ..

# 2. Configure env
cp .env.example .env
# Edit .env with your credentials

# 3. Start both servers
npm run dev
# Backend:  http://localhost:3001
# Frontend: http://localhost:5173
```

---

## Staying Live for 90 Days

The bounty requires your demo URL to stay live for at least 90 days.

- **Railway**: Free tier keeps services alive; paid plans ($5/mo) ensure no sleep
- **Render**: Free tier sleeps after 15 min inactivity — upgrade to Starter ($7/mo)  
- **Fly.io**: Free allowance usually covers a small Node app for 90 days
- **VPS**: DigitalOcean/Hetzner droplet ~$4/mo — most reliable option

Add an uptime monitor (UptimeRobot free tier) to ping your URL every 5 minutes
and alert you if it goes down.
