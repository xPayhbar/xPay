// frontend/src/wallet/walletConnect.ts
// Hedera WalletConnect integration using @hashgraph/hedera-wallet-connect
// Supports: HashPack, Blade, Kabila, MetaMask (via EVM)
// Standard: HIP-820 / WalletConnect 2.0

import {
  DAppConnector,
  HederaJsonRpcMethod,
  HederaSessionEvent,
  HederaChainId,
  SignAndExecuteTransactionParams,
  transactionToBase64String,
} from "@hashgraph/hedera-wallet-connect";
import {
  TransferTransaction,
  AccountId,
  Hbar,
  LedgerId,
} from "@hashgraph/sdk";

// ── Types ──────────────────────────────────────────────────────────────────
export interface WalletState {
  connected:  boolean;
  accountId:  string | null;
  network:    "testnet" | "mainnet";
  walletName: string | null;
}

export type WalletEvent =
  | { type: "connected";    accountId: string; walletName: string }
  | { type: "disconnected" }
  | { type: "error";        message: string };

type WalletListener = (event: WalletEvent) => void;

// ── WalletConnect Project ID ───────────────────────────────────────────────
// Get a free project ID at https://cloud.walletconnect.com
// For demo/testnet use you can use this public one; replace for production.
const WC_PROJECT_ID =
  import.meta.env.VITE_WALLETCONNECT_PROJECT_ID ?? "a6f1b5c3d2e4f7a8b9c0d1e2f3a4b5c6";

const APP_METADATA = {
  name:        "xPay",
  description: "AI-powered payment agent with runtime policy enforcement",
  url:         window.location.origin,
  icons:       [`${window.location.origin}/favicon.ico`],
};

// ── Singleton connector ────────────────────────────────────────────────────
let _connector: DAppConnector | null = null;
let _state: WalletState = {
  connected: false, accountId: null, network: "testnet", walletName: null,
};
const _listeners = new Set<WalletListener>();

function notify(event: WalletEvent) {
  _listeners.forEach((l) => l(event));
}

export function onWalletEvent(listener: WalletListener): () => void {
  _listeners.add(listener);
  return () => _listeners.delete(listener);
}

export function getWalletState(): WalletState {
  return { ..._state };
}

// ── Init connector ─────────────────────────────────────────────────────────
export async function initWalletConnect(
  network: "testnet" | "mainnet" = "testnet"
): Promise<DAppConnector> {
  if (_connector) return _connector;

  const ledgerId = network === "mainnet" ? LedgerId.MAINNET : LedgerId.TESTNET;
  const chainId  = network === "mainnet"
    ? HederaChainId.Mainnet
    : HederaChainId.Testnet;

  _connector = new DAppConnector(
    APP_METADATA,
    ledgerId,
    WC_PROJECT_ID,
    Object.values(HederaJsonRpcMethod),
    [HederaSessionEvent.ChainChanged, HederaSessionEvent.AccountsChanged],
    [chainId]
  );

  await _connector.init({ logger: "error" });

  // Restore existing sessions
  const sessions = _connector.walletConnectClient?.session.getAll() ?? [];
  if (sessions.length > 0) {
    const session   = sessions[sessions.length - 1];
    const accountId = _extractAccountId(session);
    const name      = session.peer.metadata.name;
    if (accountId) {
      _state = { connected: true, accountId, network, walletName: name };
      notify({ type: "connected", accountId, walletName: name });
    }
  }

  return _connector;
}

// ── Connect wallet (opens QR modal) ───────────────────────────────────────
export async function connectWallet(): Promise<string> {
  const connector = await initWalletConnect();

  return new Promise((resolve, reject) => {
    connector.openModal().catch(reject);

    // Listen for session approval
    connector.walletConnectClient?.on("session_update", (event: any) => {
      const session   = connector.walletConnectClient?.session.get(event.topic);
      if (!session) return;
      const accountId = _extractAccountId(session);
      const name      = session.peer.metadata.name;
      if (accountId) {
        _state = { connected: true, accountId, network: _state.network, walletName: name };
        notify({ type: "connected", accountId, walletName: name });
        resolve(accountId);
      }
    });
  });
}

// ── Disconnect ─────────────────────────────────────────────────────────────
export async function disconnectWallet(): Promise<void> {
  if (!_connector) return;
  await _connector.disconnectAll();
  _state = { connected: false, accountId: null, network: _state.network, walletName: null };
  notify({ type: "disconnected" });
}

// ── Sign + execute a transfer via the connected wallet ─────────────────────
// This is the key function for the policy agent:
// the transaction bytes are built here, sent to the wallet for user signing,
// and submitted to Hedera — the agent's private key is NEVER exposed.
export async function signAndExecuteTransfer(params: {
  toAccountId: string;
  amount:      number;
  currency:    "HBAR" | "USDC";
  memo?:       string;
}): Promise<{ txHash: string }> {
  if (!_connector || !_state.connected || !_state.accountId) {
    throw new Error("Wallet not connected. Please connect a wallet first.");
  }

  const signer    = _connector.getSigner(AccountId.fromString(_state.accountId));
  const fromId    = AccountId.fromString(_state.accountId);
  const toId      = AccountId.fromString(params.toAccountId);
  const tinybars  = Math.round(params.amount * 1e8);

  // Build transaction (HBAR; extend for USDC HTS token transfer)
  const tx = await new TransferTransaction()
    .addHbarTransfer(fromId, Hbar.fromTinybars(-tinybars))
    .addHbarTransfer(toId,   Hbar.fromTinybars(tinybars))
    .setTransactionMemo(params.memo ?? "xPay payment")
    .freezeWithSigner(signer);

  // Send to wallet for user approval + signing
  const result = await _connector.signAndExecuteTransaction({
    signerAccountId: `hedera:testnet:${_state.accountId}`,
    transactionList: transactionToBase64String(tx),
  } as SignAndExecuteTransactionParams);

  const txHash = (result as any)?.transactionId
    ?? (result as any)?.result?.transactionId
    ?? `${_state.accountId}-${Date.now()}`;

  return { txHash };
}

// ── Helpers ────────────────────────────────────────────────────────────────
function _extractAccountId(session: any): string | null {
  try {
    const accounts: string[] = Object.values(session.namespaces)
      .flatMap((ns: any) => ns.accounts ?? []);
    // accounts look like "hedera:testnet:0.0.12345"
    const raw = accounts[0]?.split(":")[2];
    return raw ?? null;
  } catch {
    return null;
  }
}
