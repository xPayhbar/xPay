// frontend/src/wallet/useWallet.ts
// React hook — exposes wallet state and actions to components

import { useState, useEffect, useCallback } from "react";
import {
  initWalletConnect,
  connectWallet,
  disconnectWallet,
  signAndExecuteTransfer,
  getWalletState,
  onWalletEvent,
  type WalletState,
} from "./walletConnect";

export interface UseWalletReturn extends WalletState {
  connecting:    boolean;
  error:         string | null;
  connect:       () => Promise<void>;
  disconnect:    () => Promise<void>;
  signTransfer:  (params: {
    toAccountId: string;
    amount:      number;
    currency:    "HBAR" | "USDC";
    memo?:       string;
  }) => Promise<{ txHash: string }>;
}

export function useWallet(network: "testnet" | "mainnet" = "testnet"): UseWalletReturn {
  const [state,      setState]      = useState<WalletState>(getWalletState());
  const [connecting, setConnecting] = useState(false);
  const [error,      setError]      = useState<string | null>(null);

  // Init on mount + subscribe to events
  useEffect(() => {
    initWalletConnect(network).catch((e) =>
      console.warn("WalletConnect init:", e?.message)
    );

    const unsub = onWalletEvent((event) => {
      if (event.type === "connected") {
        setState({ connected: true, accountId: event.accountId,
                   network, walletName: event.walletName });
        setError(null);
      } else if (event.type === "disconnected") {
        setState({ connected: false, accountId: null, network, walletName: null });
      } else if (event.type === "error") {
        setError(event.message);
      }
    });

    return unsub;
  }, [network]);

  const connect = useCallback(async () => {
    setConnecting(true);
    setError(null);
    try {
      await connectWallet();
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Connection failed");
    } finally {
      setConnecting(false);
    }
  }, []);

  const disconnect = useCallback(async () => {
    await disconnectWallet();
  }, []);

  const signTransfer = useCallback(async (params: {
    toAccountId: string;
    amount:      number;
    currency:    "HBAR" | "USDC";
    memo?:       string;
  }) => {
    return signAndExecuteTransfer(params);
  }, []);

  return { ...state, connecting, error, connect, disconnect, signTransfer };
}
