// frontend/src/App.tsx — xPay with WalletConnect
import { useState, useRef, useEffect, useCallback } from "react";
import { useWallet } from "./wallet/useWallet";
import type { PolicyConfig, SpendState, Transaction } from "./hooks/useApi";

const T = {
  bg:"#04070d",surface:"#090f1c",surface2:"#0e1828",
  border:"#152236",border2:"#1c3050",
  accent:"#00d4f5",accent2:"#0099b5",
  green:"#00e5a0",amber:"#ffb800",red:"#ff3d60",
  hedera:"#7c3aed",hedera2:"#a78bfa",
  text:"#e0f0ff",muted:"#4a6a8a",faint:"#162030",
};

const SERVICES: Record<string,{name:string;icon:string}> = {
  "0.0.4567890":{name:"OpenAI API",icon:"🤖"},
  "0.0.8901234":{name:"Pinecone DB",icon:"🌲"},
  "0.0.2345678":{name:"Twilio SMS",icon:"📱"},
  "0.0.3456789":{name:"IPFS Storage",icon:"📦"},
  "0.0.6789012":{name:"TheGraph API",icon:"📊"},
  "0.0.5432100":{name:"Chainlink Oracle",icon:"🔗"},
};

const PRESETS = [
  {label:"✅ Pay OpenAI 50 ℏ",      msg:"Pay 50 HBAR to OpenAI API (0.0.4567890) for API credits"},
  {label:"🚫 Exceed spend limit",   msg:"Send 5000 HBAR to OpenAI API (0.0.4567890) for bulk access"},
  {label:"🚫 Unknown account",      msg:"Transfer 80 HBAR to account 0.0.9999999"},
  {label:"⏳ Needs approval",       msg:"Send 300 HBAR to Twilio SMS (0.0.2345678) for a campaign"},
  {label:"🌲 Pinecone 20 USDC",    msg:"Purchase 20 USDC of Pinecone DB storage (0.0.8901234)"},
  {label:"📊 Check spending",       msg:"What is my spending today?"},
];

const uid  = () => Math.random().toString(36).slice(2,9);
const now  = () => new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
const short= (h:string) => h ? h.slice(0,12)+"…"+h.slice(-6) : "";
const rHash= () => "0x"+Array.from({length:40},()=>"0123456789abcdef"[Math.floor(Math.random()*16)]).join("");

const DEFAULT_CONFIG: PolicyConfig = {
  spendLimit:{enabled:true,hbar:500,usdc:100},
  allowlist:{enabled:true,accounts:["0.0.4567890","0.0.8901234","0.0.2345678","0.0.3456789"]},
  approvalThreshold:{enabled:true,hbar:100},
  anomalyDetection:{enabled:true},
};

async function callAgent(msg:string, policies:PolicyConfig, spend:SpendState, token:string) {
  const res = await fetch("/api/chat",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message:msg,conversationId:`conv-${Date.now()}`,policyConfig:policies}),
  });
  if(!res.ok) throw new Error(await res.text());
  return res.json();
}

type Msg = {id:string;role:"user"|"agent"|"policy"|"wallet";time:string;text?:string;
            policyType?:"approved"|"blocked"|"pending";card?:any;detail?:string};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Outfit:wght@300;400;500;600;700;800&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:${T.bg};color:${T.text};font-family:'Outfit',sans-serif;overflow:hidden}
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:${T.border2};border-radius:2px}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes walletGlow{0%,100%{box-shadow:0 0 12px ${T.hedera}55}50%{box-shadow:0 0 28px ${T.hedera}cc}}
.fadeup{animation:fadeUp .3s ease both}
input[type=range]{-webkit-appearance:none;height:4px;border-radius:2px;outline:none;background:${T.border}}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;cursor:pointer}
button{font-family:'Outfit',sans-serif;cursor:pointer;border:none;outline:none}
textarea{font-family:'Outfit',sans-serif;outline:none}
`;

export default function App() {
  const wallet = useWallet("testnet");
  const [policies,setPolicies] = useState<PolicyConfig>(DEFAULT_CONFIG);
  const [token,setToken]       = useState<"HBAR"|"USDC">("HBAR");
  const [spend,setSpend]       = useState<SpendState>({hbar:142.5,usdc:18.0,windowStart:new Date().toISOString()});
  const [msgs,setMsgs]         = useState<Msg[]>([{
    id:uid(),role:"agent",time:now(),
    text:"Hello! I'm your xPay. Connect your wallet to sign transactions directly, or I'll use the server keypair. All payments enforce spend limits, allowlists, and approval gates.",
  }]);
  const [input,setInput]       = useState("");
  const [busy,setBusy]         = useState(false);
  const [txLog,setTxLog]       = useState<any[]>([]);
  const [modal,setModal]       = useState<any>(null);
  const [walletTab,setWalletTab] = useState(false);
  const msgsRef = useRef<HTMLDivElement>(null);

  useEffect(()=>{msgsRef.current?.scrollTo({top:msgsRef.current.scrollHeight,behavior:"smooth"});},[msgs]);

  const add = (m:Omit<Msg,"id"|"time">) => setMsgs(p=>[...p,{...m,id:uid(),time:now()}]);

  // When wallet connects, show a status message in chat
  useEffect(()=>{
    if(wallet.connected && wallet.accountId){
      add({role:"wallet",text:`✅ Wallet connected: ${wallet.accountId} via ${wallet.walletName ?? "WalletConnect"}. Transactions will now be signed by your wallet.`});
    }
  },[wallet.connected, wallet.accountId]);

  const send = useCallback(async(text?:string)=>{
    const msg=(text||input).trim();
    if(!msg||busy) return;
    setInput(""); add({role:"user",text:msg}); setBusy(true);
    try {
      const data = await callAgent(msg, policies, spend, token);
      if(data.spendState) setSpend(data.spendState);
      const pr = data.policyResult;
      if(pr?.policyTriggered){
        const labels:Record<string,string>={
          spend_limit:"🚫 SPEND LIMIT TRIGGERED",allowlist:"🚫 ALLOWLIST BLOCKED",
          approval_threshold:"⏳ APPROVAL REQUIRED",anomaly:"⚠️ ANOMALY DETECTED",
        };
        add({role:"policy",policyType:pr.decision==="approved"?"approved":pr.decision==="needs_approval"?"pending":"blocked",
          text:labels[pr.policyTriggered]??"POLICY EVENT",detail:pr.violations?.[0]?.detail});
      }
      if(pr?.decision==="needs_approval"){
        const match = data.response.match(/pending-[\w-]+/);
        const pid   = match?.[0] ?? `pending-${Date.now()}`;
        setModal({pendingId:pid,amount:data.transaction?.request?.amount??0,
          currency:data.transaction?.request?.currency??token,
          accountId:data.transaction?.request?.toAccountId??"unknown",
          service:data.transaction?.request?.serviceName});
      }
      if(data.transaction) setTxLog(l=>[data.transaction,...l].slice(0,30));
      add({role:"agent",text:data.response,
        card:data.transaction?{amount:data.transaction.request.amount,currency:data.transaction.request.currency,
          accountId:data.transaction.request.toAccountId,service:data.transaction.request.serviceName,
          hash:data.transaction.txHash,decision:data.transaction.decision}:undefined});
    } catch(e:any){
      add({role:"agent",text:`⚠️ ${e.message||"Error. Try again."}`});
    }
    setBusy(false);
  },[input,busy,policies,spend,token]);

  const approve = async()=>{
    if(!modal) return;
    try {
      let txHash:string;
      if(wallet.connected){
        // Sign via user's connected wallet
        const result = await wallet.signTransfer({
          toAccountId:modal.accountId,amount:modal.amount,
          currency:modal.currency,memo:`xPay approval: ${modal.service??modal.accountId}`,
        });
        txHash = result.txHash;
        add({role:"wallet",text:`🔐 Signed by wallet ${wallet.accountId}. TX: ${short(txHash)}`});
      } else {
        // Fallback: server-side keypair
        const res = await fetch(`/api/approve/${modal.pendingId}`,{method:"POST"});
        const d   = await res.json();
        if(d.spendState) setSpend(d.spendState);
        txHash = d.transaction?.txHash ?? rHash();
      }
      setSpend(s=>({...s,[modal.currency==="HBAR"?"hbar":"usdc"]:s[modal.currency==="HBAR"?"hbar":"usdc"]+modal.amount}));
      setTxLog(l=>[{id:uid(),service:modal.service??modal.accountId,amount:modal.amount,currency:modal.currency,
        status:"ok",hash:txHash,time:now(),policy:"approval_threshold"},...l].slice(0,30));
      add({role:"policy",policyType:"approved",text:"✅ HUMAN APPROVED"});
      add({role:"agent",text:`Approved. ${modal.amount} ${modal.currency} → ${modal.service??modal.accountId}. TX: ${short(txHash)}`,
        card:{amount:modal.amount,currency:modal.currency,accountId:modal.accountId,service:modal.service,hash:txHash,decision:"approved"}});
    } catch(e:any){
      add({role:"agent",text:`Approval failed: ${e.message}`});
    }
    setModal(null);
  };

  const reject = ()=>{
    if(!modal) return;
    setTxLog(l=>[{id:uid(),service:modal.service??modal.accountId,amount:modal.amount,currency:modal.currency,
      status:"fail",hash:null,time:now(),policy:"approval_threshold"},...l].slice(0,30));
    add({role:"policy",policyType:"blocked",text:"❌ HUMAN REJECTED"});
    add({role:"agent",text:"Transaction rejected. No funds transferred."});
    setModal(null);
  };

  const spendVal = spend[token==="HBAR"?"hbar":"usdc"];
  const spendCap = policies.spendLimit[token==="HBAR"?"hbar":"usdc"];
  const pct      = Math.min(100,(spendVal/spendCap)*100);
  const overWarn = pct>70;

  return (
    <>
      <style>{CSS}</style>

      {/* BG */}
      <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:0,
        background:`radial-gradient(ellipse 65% 45% at 12% 0%,${T.hedera}22 0%,transparent 55%),
                   radial-gradient(ellipse 50% 35% at 88% 100%,${T.accent}12 0%,transparent 55%)`}}/>
      <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:0,
        backgroundImage:`linear-gradient(${T.accent}06 1px,transparent 1px),linear-gradient(90deg,${T.accent}06 1px,transparent 1px)`,
        backgroundSize:"52px 52px"}}/>

      {/* MODAL */}
      {modal && (
        <div style={{position:"fixed",inset:0,background:"rgba(4,7,13,.9)",backdropFilter:"blur(14px)",
          zIndex:500,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div className="fadeup" style={{background:T.surface,border:`1px solid ${T.border2}`,
            borderRadius:16,padding:30,width:400,boxShadow:`0 28px 80px rgba(0,0,0,.8)`}}>
            <div style={{fontSize:17,fontWeight:700,marginBottom:6}}>⏳ Approval Required</div>
            <div style={{fontSize:12,color:T.muted,marginBottom:22}}>
              {wallet.connected
                ? `Your wallet (${wallet.accountId}) will sign this transaction.`
                : "No wallet connected — server keypair will be used."}
            </div>
            {[["Service",modal.service??"Unknown"],["Amount",`${modal.amount} ${modal.currency}`],
              ["Account",modal.accountId],["Signing",wallet.connected?`Wallet: ${wallet.accountId}`:"Server keypair"]
            ].map(([k,v])=>(
              <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",
                borderBottom:`1px solid ${T.border}`,fontSize:13}}>
                <span style={{color:T.muted}}>{k}</span>
                <span style={{color:k==="Amount"?T.amber:k==="Signing"&&wallet.connected?T.hedera2:T.text,
                  fontFamily:k==="Account"?"var(--mono,monospace)":"inherit",fontSize:k==="Account"?11:13,fontWeight:k==="Amount"?700:400}}>{v}</span>
              </div>
            ))}
            {/* Wallet connect prompt if not connected */}
            {!wallet.connected && (
              <div style={{marginTop:14,padding:12,background:`${T.hedera}15`,border:`1px solid ${T.hedera}33`,
                borderRadius:8,fontSize:12,color:T.hedera2}}>
                💡 Connect a wallet above to sign this transaction yourself instead of using the server keypair.
              </div>
            )}
            <div style={{display:"flex",gap:10,marginTop:20}}>
              <button onClick={reject} style={{flex:1,padding:12,borderRadius:9,
                background:T.surface2,border:`1px solid ${T.border2}`,color:T.muted,fontSize:14,fontWeight:600}}>
                Reject
              </button>
              <button onClick={approve} style={{flex:1,padding:12,borderRadius:9,
                background:wallet.connected?T.hedera:T.green,border:"none",
                color:"white",fontSize:14,fontWeight:800}}>
                {wallet.connected?"Sign with Wallet ✓":"Approve ✓"}
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={{display:"grid",gridTemplateRows:"60px 1fr",height:"100vh",position:"relative",zIndex:1}}>

        {/* HEADER */}
        <header style={{display:"flex",alignItems:"center",justifyContent:"space-between",
          padding:"0 22px",borderBottom:`1px solid ${T.border}`,
          background:"rgba(4,7,13,.9)",backdropFilter:"blur(16px)"}}>
          <div style={{display:"flex",alignItems:"center",gap:11}}>
            <div style={{width:34,height:34,borderRadius:8,fontSize:18,
              background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:`0 0 18px ${T.hedera}66`}}>ℏ</div>
            <div>
              <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:13,fontWeight:700}}>
                xPay
              </div>
              <div style={{fontSize:10,color:T.muted,letterSpacing:".1em",textTransform:"uppercase"}}>
                Agent Kit V4 · Hooks & Policies · WalletConnect
              </div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            {/* Wallet Connect button */}
            {wallet.connected ? (
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:8,height:8,borderRadius:"50%",background:T.green,
                  boxShadow:`0 0 8px ${T.green}`}}/>
                <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,
                  color:T.green,maxWidth:140,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                  {wallet.accountId}
                </span>
                <button onClick={()=>wallet.disconnect()}
                  style={{fontSize:11,padding:"3px 10px",borderRadius:5,
                    background:`${T.red}15`,border:`1px solid ${T.red}30`,color:T.red}}>
                  Disconnect
                </button>
              </div>
            ) : (
              <button onClick={()=>wallet.connect()} disabled={wallet.connecting}
                style={{display:"flex",alignItems:"center",gap:7,fontSize:12,fontWeight:700,
                  padding:"7px 16px",borderRadius:8,border:`1px solid ${T.hedera2}`,
                  background:`${T.hedera}25`,color:T.hedera2,
                  opacity:wallet.connecting?.6:1,
                  animation:!wallet.connecting?"walletGlow 3s ease-in-out infinite":undefined}}>
                {wallet.connecting
                  ? <><div style={{width:10,height:10,border:`2px solid ${T.hedera2}`,borderTopColor:"transparent",
                      borderRadius:"50%",animation:"spin .8s linear infinite"}}/>Connecting…</>
                  : <>🔗 Connect Wallet</>}
              </button>
            )}
            {wallet.error && (
              <span style={{fontSize:11,color:T.red,maxWidth:160,overflow:"hidden",textOverflow:"ellipsis"}}>
                {wallet.error}
              </span>
            )}
            <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:T.green,
              padding:"3px 10px",borderRadius:4,background:`${T.green}10`,border:`1px solid ${T.green}25`}}>
              TESTNET
            </span>
          </div>
        </header>

        {/* 3-COL MAIN */}
        <div style={{display:"grid",gridTemplateColumns:"300px 1fr 260px",overflow:"hidden"}}>

          {/* LEFT: Policy Config */}
          <aside style={{borderRight:`1px solid ${T.border}`,overflowY:"auto",padding:16,
            display:"flex",flexDirection:"column",gap:12}}>
            <PTitle color={T.accent}>Policy Configuration</PTitle>

            {/* Token */}
            <div>
              <FLabel>Payment Token</FLabel>
              <div style={{display:"flex",gap:6}}>
                {(["HBAR","USDC"] as const).map(t=>(
                  <button key={t} onClick={()=>setToken(t)}
                    style={{flex:1,padding:"7px 0",borderRadius:7,fontSize:12,fontWeight:700,
                      fontFamily:"'JetBrains Mono',monospace",
                      border:`1px solid ${token===t?(t==="HBAR"?T.hedera2:T.accent):T.border}`,
                      background:token===t?`${t==="HBAR"?T.hedera:T.accent}18`:T.surface2,
                      color:token===t?(t==="HBAR"?T.hedera2:T.accent):T.muted}}>
                    {t==="HBAR"?"ℏ HBAR":"＄USDC"}
                  </button>
                ))}
              </div>
            </div>

            {/* Wallet status */}
            <Card>
              <FLabel>Wallet Connection</FLabel>
              {wallet.connected ? (
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                    <div style={{width:8,height:8,borderRadius:"50%",background:T.green,
                      boxShadow:`0 0 6px ${T.green}`}}/>
                    <span style={{fontSize:12,color:T.green,fontWeight:700}}>{wallet.walletName??"Connected"}</span>
                  </div>
                  <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:T.text,
                    background:T.surface2,padding:"6px 8px",borderRadius:5,wordBreak:"break-all"}}>
                    {wallet.accountId}
                  </div>
                  <div style={{fontSize:10,color:T.muted,marginTop:6}}>
                    ✓ High-value transfers will be signed by your wallet, not the server keypair.
                  </div>
                </div>
              ) : (
                <div>
                  <div style={{fontSize:12,color:T.muted,marginBottom:10,lineHeight:1.5}}>
                    Connect HashPack, Blade, Kabila, or any WalletConnect-compatible Hedera wallet.
                  </div>
                  <button onClick={()=>wallet.connect()} disabled={wallet.connecting}
                    style={{width:"100%",padding:"9px 0",borderRadius:8,fontWeight:700,fontSize:13,
                      background:`linear-gradient(135deg,${T.hedera},${T.hedera2}55)`,
                      border:`1px solid ${T.hedera2}`,color:"white",
                      opacity:wallet.connecting?.6:1}}>
                    {wallet.connecting?"Connecting…":"🔗 Connect Wallet"}
                  </button>
                  <div style={{fontSize:10,color:T.muted,marginTop:8,textAlign:"center"}}>
                    Supports HashPack · Blade · Kabila · MetaMask
                  </div>
                </div>
              )}
            </Card>

            {/* Policy toggles */}
            <Card>
              <FLabel>Active Policies (V4)</FLabel>
              {[
                {key:"spendLimit"       ,label:"Spend Limit",        desc:"AbstractPolicy — daily cap"},
                {key:"allowlist"        ,label:"Counterparty Allowlist",desc:"AbstractPolicy — approved accounts"},
                {key:"approvalThreshold",label:"Human Approval",     desc:"AbstractPolicy — gates high-value"},
                {key:"anomalyDetection" ,label:"Anomaly Detection",  desc:"AbstractPolicy — flags suspicious"},
              ].map(({key,label,desc})=>(
                <div key={key} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
                  padding:"9px 0",borderBottom:`1px solid ${T.border}`}}>
                  <div>
                    <div style={{fontSize:13,fontWeight:600}}>{label}</div>
                    <div style={{fontSize:10,color:T.muted,marginTop:1,fontFamily:"'JetBrains Mono',monospace"}}>{desc}</div>
                  </div>
                  <Toggle on={(policies[key as keyof PolicyConfig] as any).enabled}
                    onChange={()=>setPolicies(p=>({...p,[key]:{...(p[key as keyof PolicyConfig] as any),enabled:!(p[key as keyof PolicyConfig] as any).enabled}}))}/>
                </div>
              ))}
            </Card>

            {/* Sliders */}
            {policies.spendLimit.enabled && (
              <Card>
                <FLabel>Daily Cap — {token}</FLabel>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:T.muted,marginBottom:6}}>
                  <span>0</span>
                  <span style={{color:T.accent,fontFamily:"'JetBrains Mono',monospace",fontWeight:700}}>
                    {policies.spendLimit[token==="HBAR"?"hbar":"usdc"]} {token}
                  </span>
                  <span>1000</span>
                </div>
                <input type="range" min={50} max={1000} step={50}
                  value={policies.spendLimit[token==="HBAR"?"hbar":"usdc"]}
                  onChange={e=>setPolicies(p=>({...p,spendLimit:{...p.spendLimit,[token==="HBAR"?"hbar":"usdc"]:+e.target.value}}))}
                  style={{width:"100%",accentColor:T.accent}}/>
              </Card>
            )}
            {policies.approvalThreshold.enabled && (
              <Card>
                <FLabel>Approval Threshold (HBAR)</FLabel>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:T.muted,marginBottom:6}}>
                  <span>10</span>
                  <span style={{color:T.amber,fontFamily:"'JetBrains Mono',monospace",fontWeight:700}}>
                    {policies.approvalThreshold.hbar} ℏ
                  </span>
                  <span>500</span>
                </div>
                <input type="range" min={10} max={500} step={10}
                  value={policies.approvalThreshold.hbar}
                  onChange={e=>setPolicies(p=>({...p,approvalThreshold:{...p.approvalThreshold,hbar:+e.target.value}}))}
                  style={{width:"100%",accentColor:T.amber}}/>
              </Card>
            )}

            {/* Allowlist */}
            {policies.allowlist.enabled && (
              <Card>
                <FLabel>Approved Counterparties</FLabel>
                {policies.allowlist.accounts.map(acc=>{
                  const s=SERVICES[acc];
                  return (
                    <div key={acc} style={{display:"flex",alignItems:"center",gap:8,
                      padding:"7px 10px",background:T.surface2,border:`1px solid ${T.border}`,
                      borderRadius:7,marginBottom:5}}>
                      <span style={{fontSize:15}}>{s?.icon??"🏢"}</span>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontSize:12,fontWeight:600}}>{s?.name??acc}</div>
                        <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:T.muted}}>{acc}</div>
                      </div>
                      <button onClick={()=>setPolicies(p=>({...p,allowlist:{...p.allowlist,
                          accounts:p.allowlist.accounts.filter(a=>a!==acc)}}))}
                        style={{background:"none",color:T.muted,fontSize:16,lineHeight:1,padding:"0 2px"}}>×</button>
                    </div>
                  );
                })}
                {Object.keys(SERVICES).filter(a=>!policies.allowlist.accounts.includes(a)).length>0 && (
                  <button onClick={()=>{
                    const u=Object.keys(SERVICES).find(a=>!policies.allowlist.accounts.includes(a));
                    if(u) setPolicies(p=>({...p,allowlist:{...p.allowlist,accounts:[...p.allowlist.accounts,u]}}));
                  }} style={{width:"100%",padding:8,borderRadius:7,border:`1px dashed ${T.border2}`,
                    background:"none",color:T.muted,fontSize:12}}>+ Add service</button>
                )}
              </Card>
            )}
          </aside>

          {/* CENTER: Chat */}
          <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
            <div style={{padding:"12px 18px",borderBottom:`1px solid ${T.border}`,
              display:"flex",alignItems:"center",gap:12}}>
              <div style={{width:40,height:40,borderRadius:"50%",flexShrink:0,
                background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,
                boxShadow:`0 0 20px ${T.hedera}66`}}>🤖</div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700}}>xPay</div>
                <div style={{fontSize:11,color:T.green}}>
                  ● V4 Hooks · WalletConnect {wallet.connected?`· ${wallet.accountId}`:"· No wallet"}
                </div>
              </div>
              {busy && (
                <div style={{display:"flex",alignItems:"center",gap:7,fontFamily:"'JetBrains Mono',monospace",
                  fontSize:10,color:T.amber,background:`${T.amber}12`,border:`1px solid ${T.amber}30`,
                  padding:"4px 12px",borderRadius:5}}>
                  <div style={{width:10,height:10,border:`2px solid ${T.amber}`,borderTopColor:"transparent",
                    borderRadius:"50%",animation:"spin .8s linear infinite"}}/>EVALUATING
                </div>
              )}
            </div>

            {/* Presets */}
            <div style={{padding:"8px 16px",borderBottom:`1px solid ${T.border}`,display:"flex",gap:6,flexWrap:"wrap"}}>
              {PRESETS.map(p=>(
                <button key={p.label} onClick={()=>!busy&&send(p.msg)} disabled={busy}
                  style={{fontSize:11,padding:"4px 12px",borderRadius:20,border:`1px solid ${T.border2}`,
                    background:T.surface2,color:T.muted,whiteSpace:"nowrap",opacity:busy?.5:1}}>
                  {p.label}
                </button>
              ))}
            </div>

            {/* Messages */}
            <div ref={msgsRef} style={{flex:1,overflowY:"auto",padding:"18px",display:"flex",flexDirection:"column",gap:11}}>
              {msgs.map(m=>{
                if(m.role==="policy"){
                  const c=m.policyType==="approved"?T.green:m.policyType==="blocked"?T.red:T.amber;
                  return (
                    <div key={m.id} className="fadeup" style={{alignSelf:"center",display:"flex",
                      flexDirection:"column",alignItems:"center",gap:3,maxWidth:"85%"}}>
                      <div style={{background:`${c}0e`,border:`1px solid ${c}33`,borderRadius:7,
                        padding:"6px 16px",fontSize:11,color:c,fontFamily:"'JetBrains Mono',monospace"}}>
                        {m.text}
                      </div>
                      {m.detail&&<div style={{fontSize:10,color:T.muted,textAlign:"center"}}>{m.detail}</div>}
                    </div>
                  );
                }
                if(m.role==="wallet"){
                  return (
                    <div key={m.id} className="fadeup" style={{alignSelf:"center",background:`${T.hedera}12`,
                      border:`1px solid ${T.hedera}33`,borderRadius:7,padding:"7px 16px",
                      fontSize:11,color:T.hedera2,maxWidth:"90%",textAlign:"center"}}>
                      {m.text}
                    </div>
                  );
                }
                const isUser=m.role==="user";
                return (
                  <div key={m.id} className="fadeup" style={{alignSelf:isUser?"flex-end":"flex-start",maxWidth:"84%"}}>
                    <div style={{padding:"11px 15px",lineHeight:1.65,fontSize:13,
                      borderRadius:isUser?"14px 14px 3px 14px":"14px 14px 14px 3px",
                      background:isUser?`linear-gradient(135deg,${T.hedera},${T.accent2})`:T.surface,
                      border:isUser?"none":`1px solid ${T.border2}`}}>
                      {m.text}
                      {m.card&&m.card.amount>0&&(
                        <div style={{background:T.surface2,border:`1px solid ${T.border}`,borderRadius:8,
                          padding:11,marginTop:10,fontFamily:"'JetBrains Mono',monospace",fontSize:11}}>
                          {[["Status",m.card.decision==="approved"?"✓ EXECUTED":"✗ BLOCKED",
                              m.card.decision==="approved"?T.green:T.red],
                            ["Amount",`${m.card.amount} ${m.card.currency}`,T.text],
                            ["To",m.card.service??m.card.accountId,T.text],
                            ...(m.card.hash?[["TX Hash",short(m.card.hash),T.muted]]:[]),
                          ].map(([k,v,c])=>(
                            <div key={k as string} style={{display:"flex",justifyContent:"space-between",
                              padding:"4px 0",borderBottom:`1px solid ${T.border}`,fontSize:10}}>
                              <span style={{color:T.muted}}>{k}</span>
                              <span style={{color:c as string,fontWeight:k==="Status"||k==="Amount"?700:400}}>{v}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div style={{fontSize:10,color:T.muted,marginTop:3,padding:"0 4px",
                      textAlign:isUser?"right":"left"}}>{m.time}</div>
                  </div>
                );
              })}
              {busy&&(
                <div className="fadeup" style={{alignSelf:"flex-start",padding:"11px 16px",
                  borderRadius:"14px 14px 14px 3px",background:T.surface,border:`1px solid ${T.border2}`,
                  fontSize:13,color:T.muted,display:"flex",gap:8,alignItems:"center"}}>
                  <div style={{display:"flex",gap:3}}>
                    {[0,1,2].map(i=>(
                      <div key={i} style={{width:5,height:5,borderRadius:"50%",background:T.muted,
                        animation:`pulse 1.2s ${i*.2}s infinite`}}/>
                    ))}
                  </div>
                  Checking policies…
                </div>
              )}
            </div>

            {/* Input */}
            <div style={{padding:"13px 16px",borderTop:`1px solid ${T.border}`,display:"flex",gap:9,alignItems:"flex-end"}}>
              <textarea value={input} onChange={e=>setInput(e.target.value)}
                onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}}
                placeholder={`e.g. "Pay 50 HBAR to OpenAI for API credits"`}
                rows={1}
                style={{flex:1,background:T.surface,border:`1px solid ${T.border2}`,borderRadius:9,
                  color:T.text,fontSize:13,padding:"10px 14px",resize:"none",minHeight:42,maxHeight:110}}/>
              <button onClick={()=>send()} disabled={busy||!input.trim()}
                style={{padding:"0 20px",background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
                  borderRadius:9,color:"white",fontSize:13,fontWeight:700,height:42,flexShrink:0,
                  opacity:busy||!input.trim()?.4:1}}>Send ↑</button>
            </div>
          </div>

          {/* RIGHT: Ledger */}
          <aside style={{borderLeft:`1px solid ${T.border}`,overflowY:"auto",padding:16,
            display:"flex",flexDirection:"column",gap:12}}>
            <PTitle color={T.green}>Spend Tracker</PTitle>

            <Card>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:T.muted,marginBottom:8}}>
                <span>Daily Usage</span>
                <span style={{color:overWarn?T.amber:T.green,fontFamily:"'JetBrains Mono',monospace",fontWeight:700}}>
                  {spendVal.toFixed(1)} / {spendCap} {token}
                </span>
              </div>
              <div style={{height:5,background:T.faint,borderRadius:3,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${pct}%`,borderRadius:3,transition:"width .6s ease",
                  background:overWarn?`linear-gradient(90deg,${T.amber},${T.red})`:`linear-gradient(90deg,${T.green},${T.accent})`}}/>
              </div>
            </Card>

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <Mini label="Sent"    value={txLog.filter(t=>t.status==="ok").length}   color={T.green}/>
              <Mini label="Blocked" value={txLog.filter(t=>t.status==="fail").length} color={T.red}/>
            </div>

            {/* Wallet info */}
            <Card>
              <FLabel>Signing Mode</FLabel>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:8,height:8,borderRadius:"50%",flexShrink:0,
                  background:wallet.connected?T.hedera2:T.muted,
                  boxShadow:wallet.connected?`0 0 8px ${T.hedera2}`:undefined}}/>
                <div>
                  <div style={{fontSize:12,fontWeight:600,color:wallet.connected?T.hedera2:T.muted}}>
                    {wallet.connected?"Wallet Signing":"Server Keypair"}
                  </div>
                  <div style={{fontSize:10,color:T.muted,marginTop:2}}>
                    {wallet.connected
                      ? `${wallet.walletName} · ${wallet.accountId}`
                      : "Connect wallet for user-signed txns"}
                  </div>
                </div>
              </div>
            </Card>

            <PTitle color={T.accent}>Transaction Log</PTitle>
            {txLog.length===0&&(
              <div style={{color:T.muted,fontSize:12,textAlign:"center",padding:"20px 0",fontStyle:"italic"}}>
                No transactions yet
              </div>
            )}
            <div style={{display:"flex",flexDirection:"column",gap:7}}>
              {txLog.map((tx,i)=>(
                <div key={i} style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:9,padding:11}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                    <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:T.accent,fontWeight:600,
                      maxWidth:120,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                      {tx.service}
                    </span>
                    <span style={{fontSize:10,padding:"2px 8px",borderRadius:10,fontWeight:600,
                      background:tx.status==="ok"?`${T.green}18`:`${T.red}18`,
                      color:tx.status==="ok"?T.green:T.red}}>
                      {tx.status==="ok"?"Sent":"Blocked"}
                    </span>
                  </div>
                  <div style={{fontFamily:"'JetBrains Mono',monospace",fontWeight:700,fontSize:14,marginBottom:4}}>
                    {tx.amount}{" "}
                    <span style={{fontSize:10,padding:"2px 7px",borderRadius:4,
                      background:tx.currency==="HBAR"?`${T.hedera}25`:`${T.accent}15`,
                      color:tx.currency==="HBAR"?T.hedera2:T.accent,
                      border:`1px solid ${tx.currency==="HBAR"?T.hedera2:T.accent}30`}}>
                      {tx.currency}
                    </span>
                  </div>
                  <div style={{fontSize:10,color:T.muted}}>{tx.time}</div>
                  {tx.hash&&<div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,
                    color:T.faint,marginTop:5,wordBreak:"break-all"}}>{short(tx.hash)}</div>}
                </div>
              ))}
            </div>
          </aside>

        </div>
      </div>
    </>
  );
}

// Sub-components
function PTitle({children,color}:{children:React.ReactNode;color:string}){
  return (
    <div style={{display:"flex",alignItems:"center",gap:8,fontFamily:"'JetBrains Mono',monospace",
      fontSize:10,letterSpacing:".14em",textTransform:"uppercase",color:T.muted,
      paddingBottom:10,borderBottom:`1px solid ${T.border}`}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:color,boxShadow:`0 0 6px ${color}`}}/>
      {children}
    </div>
  );
}
function FLabel({children}:{children:React.ReactNode}){
  return <div style={{fontSize:10,letterSpacing:".1em",textTransform:"uppercase",color:T.muted,marginBottom:8}}>{children}</div>;
}
function Card({children}:{children:React.ReactNode}){
  return <div style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:10,padding:14}}>{children}</div>;
}
function Toggle({on,onChange}:{on:boolean;onChange:()=>void}){
  return (
    <button onClick={onChange} style={{width:36,height:20,borderRadius:10,flexShrink:0,marginLeft:12,
      background:on?T.green:T.faint,border:"none",position:"relative",cursor:"pointer"}}>
      <span style={{position:"absolute",top:2,width:16,height:16,borderRadius:"50%",
        background:"white",transition:"left .2s",left:on?18:2}}/>
    </button>
  );
}
function Mini({label,value,color}:{label:string;value:number;color:string}){
  return (
    <div style={{background:T.surface,border:`1px solid ${T.border}`,borderRadius:10,padding:"12px 14px"}}>
      <div style={{fontSize:10,letterSpacing:".1em",textTransform:"uppercase",color:T.muted,marginBottom:6}}>{label}</div>
      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:24,fontWeight:700,color}}>{value}</div>
    </div>
  );
}
