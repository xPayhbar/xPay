// frontend/src/hooks/useApi.ts
import { useCallback, useRef } from "react";

const API = import.meta.env.VITE_API_URL ?? "";

export interface PolicyConfig {
  spendLimit: { enabled: boolean; hbar: number; usdc: number };
  allowlist: { enabled: boolean; accounts: string[] };
  approvalThreshold: { enabled: boolean; hbar: number };
  anomalyDetection: { enabled: boolean };
}

export interface PolicyViolation {
  policy: string;
  reason: string;
  detail?: string;
}

export interface PolicyResult {
  decision: "approved" | "blocked" | "needs_approval";
  violations: PolicyViolation[];
  message: string;
}

export interface Transaction {
  id: string;
  request: {
    toAccountId: string;
    amount: number;
    currency: string;
    serviceName?: string;
  };
  decision: string;
  txHash?: string;
  timestamp: string;
  violations: PolicyViolation[];
}

export interface SpendState {
  hbar: number;
  usdc: number;
  windowStart: string;
}

export interface ChatResponse {
  response: string;
  policyResult?: PolicyResult;
  transaction?: Transaction;
  spendState: SpendState;
}

export function useApi() {
  const convId = useRef(`conv-${Date.now()}`);

  const chat = useCallback(
    async (message: string, policyConfig?: Partial<PolicyConfig>): Promise<ChatResponse> => {
      const res = await fetch(`${API}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          conversationId: convId.current,
          policyConfig,
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    },
    []
  );

  const approve = useCallback(async (pendingId: string) => {
    const res = await fetch(`${API}/api/approve/${pendingId}`, { method: "POST" });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  }, []);

  const reject = useCallback(async (pendingId: string) => {
    const res = await fetch(`${API}/api/reject/${pendingId}`, { method: "POST" });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
  }, []);

  const resetSpend = useCallback(async () => {
    const res = await fetch(`${API}/api/spend/reset`, { method: "POST" });
    return res.json();
  }, []);

  return { chat, approve, reject, resetSpend, convId: convId.current };
}
