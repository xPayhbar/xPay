// Hedera Policy Agent — Full Interactive Demo
// Week 5 Bounty: Policy-constrained HBAR/USDC payments on Hedera
// Uses Claude API to simulate the LangGraph agent + policy engine

import { useState, useEffect, useRef, useCallback } from "react";

// ── Theme ─────────────────────────────────────────────────────────────────
const T = {
  bg: "#04070d", surface: "#090f1c", surface2: "#0e1828",
  border: "#152236", border2: "#1c3050",
  accent: "#00d4f5", accent2: "#0099b5",
  green: "#00e5a0", green2: "#00b57d",
  amber: "#ffb800", red: "#ff3d60",
  hedera: "#7c3aed", hedera2: "#a78bfa",
  text: "#e0f0ff", muted: "#4a6a8a", faint: "#162030",
};

// ── Known services ─────────────────────────────────────────────────────────
const SERVICES = {
  "0.0.4567890": { name: "OpenAI API",       icon: "🤖", category: "AI/ML" },
  "0.0.8901234": { name: "Pinecone DB",      icon: "🌲", category: "Database" },
  "0.0.2345678": { name: "Twilio SMS",       icon: "📱", category: "Comms" },
  "0.0.3456789": { name: "IPFS Storage",     icon: "📦", category: "Storage" },
  "0.0.6789012": { name: "TheGraph API",     icon: "📊", category: "Indexing" },
  "0.0.5432100": { name: "Chainlink Oracle", icon: "🔗", category: "Oracle" },
};

const PRESETS = [
  { label: "✅ Pay OpenAI 50 ℏ",       msg: "Pay 50 HBAR to OpenAI API (account 0.0.4567890) for GPT-4 API credits" },
  { label: "🚫 Exceed spend limit",    msg: "Send 5000 HBAR to OpenAI API (account 0.0.4567890) for bulk API access" },
  { label: "🚫 Unknown counterparty", msg: "Transfer 100 HBAR to account 0.0.9999999 for some data feed" },
  { label: "⏳ Needs approval",        msg: "Send 300 HBAR to Twilio SMS (account 0.0.2345678) for a campaign" },
  { label: "🌲 Pinecone 20 USDC",     msg: "Purchase 20 USDC of Pinecone vector DB storage (account 0.0.8901234)" },
  { label: "⚠️ Anomaly: round amt",   msg: "Send 1000 HBAR to OpenAI API (account 0.0.4567890)" },
  { label: "📊 Check my spending",    msg: "What is my spending so far today?" },
  { label: "📋 List services",         msg: "Which services can I pay, and what are their account IDs?" },
];

const uid = () => Math.random().toString(36).slice(2, 9);
const now = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const shortHash = (h) => h ? h.slice(0, 12) + "…" + h.slice(-6) : "";
const randHash = () => "0x" + Array.from({length:40}, () => "0123456789abcdef"[Math.floor(Math.random()*16)]).join("");

// ── Claude API call ────────────────────────────────────────────────────────
async function callClaude(userMsg, policies, spendState, token) {
  const allowedNames = policies.allowlist.accounts
    .map(acc => SERVICES[acc]?.name ?? acc).join(", ");

  const system = `You are the Hedera Policy Agent — an autonomous AI payment agent on the Hedera blockchain.
You evaluate payment requests and enforce policies BEFORE executing any transfer.

ACTIVE POLICIES:
${policies.spendLimit.enabled
  ? `- SPEND LIMIT: Daily cap is ${policies.spendLimit[token==="HBAR"?"hbar":"usdc"]} ${token}. Used today: ${spendState[token==="HBAR"?"hbar":"usdc"].toFixed(2)} ${token}.`
  : "- SPEND LIMIT: disabled"}
${policies.allowlist.enabled
  ? `- COUNTERPARTY ALLOWLIST: Only pay: ${allowedNames || "none"}`
  : "- COUNTERPARTY ALLOWLIST: disabled"}
${policies.approvalThreshold.enabled
  ? `- HUMAN APPROVAL: Required for HBAR transfers >= ${policies.approvalThreshold.hbar} HBAR`
  : "- HUMAN APPROVAL: disabled"}
${policies.anomalyDetection.enabled
  ? `- ANOMALY DETECTION: Flag unknown recipients, huge amounts, suspicious round numbers (>=1000 divisible by 1000)`
  : "- ANOMALY DETECTION: disabled"}

KNOWN SERVICE ACCOUNTS: ${Object.entries(SERVICES).map(([id,s])=>`${s.name}=${id}`).join("; ")}

When user requests a payment, respond ONLY with valid JSON (no markdown, no extra text):
{
  "decision": "approved" | "blocked" | "needs_approval",
  "policyTriggered": "spend_limit" | "allowlist" | "approval_threshold" | "anomaly" | null,
  "violationDetail": "short explanation of which policy fired and why",
  "toAccountId": "0.0.XXXXXXX or unknown",
  "serviceName": "service name if found, else null",
  "amount": number or 0,
  "currency": "HBAR" or "USDC",
  "pendingId": "pending-TIMESTAMP if needs_approval, else null",
  "txHash": "simulated-tx-hash-string if approved, else null",
  "agentMessage": "1-2 sentence friendly message explaining what happened. If approved mention amount and service. If blocked explain which policy blocked it. If needs_approval explain it's waiting for human sign-off."
}

For non-payment queries (balance checks, list services, etc) respond with:
{
  "decision": "info",
  "policyTriggered": null,
  "violationDetail": null,
  "toAccountId": null,
  "serviceName": null,
  "amount": 0,
  "currency": "${token}",
  "pendingId": null,
  "txHash": null,
  "agentMessage": "Your helpful answer here."
}`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system,
      messages: [{ role: "user", content: userMsg }],
    }),
  });
  const data = await res.json();
  const raw = (data.content || []).map(b => b.text || "").join("").trim();
  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    return { decision:"info", policyTriggered:null, violationDetail:null,
             toAccountId:null, serviceName:null, amount:0, currency:token,
             pendingId:null, txHash:null,
             agentMessage: raw || "I encountered an issue. Please try again." };
  }
}

// ── CSS ────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Outfit:wght@300;400;500;600;700;800&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:${T.bg};--surface:${T.surface};--surface2:${T.surface2};
  --border:${T.border};--border2:${T.border2};
  --accent:${T.accent};--green:${T.green};--amber:${T.amber};--red:${T.red};
  --hedera:${T.hedera};--hedera2:${T.hedera2};
  --text:${T.text};--muted:${T.muted};--faint:${T.faint};
  --mono:'JetBrains Mono',monospace;--sans:'Outfit',sans-serif;
}
body{background:var(--bg);color:var(--text);font-family:var(--sans);overflow:hidden}
::-webkit-scrollbar{width:3px;height:3px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes glow{0%,100%{box-shadow:0 0 8px ${T.hedera}66}50%{box-shadow:0 0 24px ${T.hedera}cc}}
.fadeup{animation:fadeUp .3s ease both}
input[type=range]{-webkit-appearance:none;height:4px;border-radius:2px;outline:none;background:var(--border)}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;cursor:pointer;margin-top:-5px}
button{font-family:var(--sans);cursor:pointer;border:none;outline:none}
textarea,input{font-family:var(--sans);outline:none}
`;

// ── Main Component ─────────────────────────────────────────────────────────
export default function HederaPolicyAgent() {
  const [policies, setPolicies] = useState({
    spendLimit:       { enabled: true,  hbar: 500, usdc: 100 },
    allowlist:        { enabled: true,  accounts: ["0.0.4567890","0.0.8901234","0.0.2345678","0.0.3456789"] },
    approvalThreshold:{ enabled: true,  hbar: 100 },
    anomalyDetection: { enabled: true },
  });
  const [token, setToken]         = useState("HBAR");
  const [spendState, setSpend]    = useState({ hbar: 142.5, usdc: 18.0 });
  const [messages, setMessages]   = useState([{
    id: uid(), role: "agent", time: now(),
    text: "Hello! I'm your Hedera Policy Agent. I enforce spend limits, counterparty allowlists, and human approval gates before executing any on-chain payment. Try one of the presets or type your own request.",
    card: null, policyEvent: null,
  }]);
  const [input, setInput]         = useState("");
  const [busy, setBusy]           = useState(false);
  const [txLog, setTxLog]         = useState([]);
  const [modal, setModal]         = useState(null); // pending approval
  const msgsRef                   = useRef(null);
  const inputRef                  = useRef(null);

  useEffect(() => {
    msgsRef.current?.scrollTo({ top: msgsRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const addMsg = (m) => setMessages(p => [...p, { id: uid(), time: now(), ...m }]);

  const send = useCallback(async (text) => {
    const msg = (text || input).trim();
    if (!msg || busy) return;
    setInput("");
    addMsg({ role: "user", text: msg });
    setBusy(true);

    try {
      const r = await callClaude(msg, policies, spendState, token);

      // Policy event banner
      if (r.policyTriggered) {
        const labels = {
          spend_limit: "🚫 SPEND LIMIT TRIGGERED",
          allowlist:   "🚫 ALLOWLIST POLICY BLOCKED",
          approval_threshold: "⏳ APPROVAL REQUIRED",
          anomaly:     "⚠️ ANOMALY DETECTED",
        };
        addMsg({
          role: "policy",
          policyType: r.decision === "approved" ? "approved" : r.decision === "needs_approval" ? "pending" : "blocked",
          text: labels[r.policyTriggered] ?? "POLICY EVENT",
          detail: r.violationDetail,
        });
      }

      // Update spend on approval
      if (r.decision === "approved" && r.amount > 0) {
        setSpend(s => ({
          ...s,
          [r.currency === "HBAR" ? "hbar" : "usdc"]:
            s[r.currency === "HBAR" ? "hbar" : "usdc"] + r.amount
        }));
        const hash = r.txHash || randHash();
        setTxLog(l => [{
          id: uid(), service: r.serviceName || r.toAccountId,
          amount: r.amount, currency: r.currency,
          status: "ok", hash, time: now(),
          policy: r.policyTriggered,
        }, ...l].slice(0, 30));
        addMsg({
          role: "agent", text: r.agentMessage,
          card: { amount: r.amount, currency: r.currency, accountId: r.toAccountId,
                  service: r.serviceName, hash, decision: "approved" },
        });
      } else if (r.decision === "needs_approval") {
        const pid = r.pendingId || `pending-${Date.now()}`;
        setModal({ pendingId: pid, amount: r.amount, currency: r.currency,
                   accountId: r.toAccountId, service: r.serviceName,
                   policy: r.policyTriggered, detail: r.violationDetail });
        addMsg({ role: "agent", text: r.agentMessage, card: null });
      } else if (r.decision === "blocked") {
        setTxLog(l => [{
          id: uid(), service: r.serviceName || r.toAccountId || "unknown",
          amount: r.amount, currency: r.currency || token,
          status: "fail", hash: null, time: now(), policy: r.policyTriggered,
        }, ...l].slice(0, 30));
        addMsg({ role: "agent", text: r.agentMessage, card: null });
      } else {
        addMsg({ role: "agent", text: r.agentMessage, card: null });
      }
    } catch (e) {
      addMsg({ role: "agent", text: `⚠️ ${e.message || "Network error. Please try again."}` });
    }
    setBusy(false);
  }, [input, busy, policies, spendState, token]);

  const handleApprove = () => {
    if (!modal) return;
    const hash = randHash();
    setSpend(s => ({
      ...s,
      [modal.currency === "HBAR" ? "hbar" : "usdc"]:
        s[modal.currency === "HBAR" ? "hbar" : "usdc"] + modal.amount
    }));
    setTxLog(l => [{
      id: uid(), service: modal.service || modal.accountId,
      amount: modal.amount, currency: modal.currency,
      status: "ok", hash, time: now(), policy: modal.policy,
    }, ...l].slice(0, 30));
    addMsg({ role: "policy", policyType: "approved", text: "✅ HUMAN APPROVED", detail: "Operator approved the transaction" });
    addMsg({
      role: "agent",
      text: `Transaction approved. ${modal.amount} ${modal.currency} sent to ${modal.service ?? modal.accountId}. TX: ${shortHash(hash)}`,
      card: { amount: modal.amount, currency: modal.currency, accountId: modal.accountId,
               service: modal.service, hash, decision: "approved" },
    });
    setModal(null);
  };

  const handleReject = () => {
    if (!modal) return;
    setTxLog(l => [{
      id: uid(), service: modal.service || modal.accountId || "unknown",
      amount: modal.amount, currency: modal.currency,
      status: "fail", hash: null, time: now(), policy: modal.policy,
    }, ...l].slice(0, 30));
    addMsg({ role: "policy", policyType: "blocked", text: "❌ HUMAN REJECTED", detail: "Operator rejected the transaction" });
    addMsg({ role: "agent", text: "Transaction rejected by operator. No funds have been transferred.", card: null });
    setModal(null);
  };

  const spendVal  = spendState[token === "HBAR" ? "hbar" : "usdc"];
  const spendCap  = policies.spendLimit[token === "HBAR" ? "hbar" : "usdc"];
  const spendPct  = Math.min(100, (spendVal / spendCap) * 100);
  const overWarn  = spendPct > 70;
  const sentCount = txLog.filter(t => t.status === "ok").length;
  const blockCount= txLog.filter(t => t.status === "fail").length;

  return (
    <>
      <style>{CSS}</style>

      {/* BG effects */}
      <div style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:0,
        background:`radial-gradient(ellipse 65% 45% at 12% 0%,${T.hedera}22 0%,transparent 55%),
                   radial-gradient(ellipse 50% 35% at 88% 100%,${T.accent}14 0%,transparent 55%)` }} />
      <div style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:0,
        backgroundImage:`linear-gradient(${T.accent}06 1px,transparent 1px),linear-gradient(90deg,${T.accent}06 1px,transparent 1px)`,
        backgroundSize:"52px 52px" }} />

      {/* ── APPROVAL MODAL ── */}
      {modal && (
        <div style={{ position:"fixed",inset:0,background:"rgba(4,7,13,.9)",backdropFilter:"blur(14px)",
          zIndex:500,display:"flex",alignItems:"center",justifyContent:"center" }}>
          <div className="fadeup" style={{ background:T.surface,border:`1px solid ${T.border2}`,borderRadius:16,
            padding:30,width:380,boxShadow:`0 28px 80px rgba(0,0,0,.8),0 0 0 1px ${T.hedera}33` }}>
            <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:6 }}>
              <div style={{ width:36,height:36,borderRadius:8,background:`${T.amber}20`,
                border:`1px solid ${T.amber}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18 }}>⏳</div>
              <div style={{ fontSize:17,fontWeight:700 }}>Approval Required</div>
            </div>
            <div style={{ fontSize:12,color:T.muted,marginBottom:22,paddingLeft:46 }}>
              This transfer exceeds the auto-approval threshold and needs your explicit sign-off.
            </div>
            {[
              ["Service",   modal.service ?? "Unknown"],
              ["Amount",    `${modal.amount} ${modal.currency}`],
              ["Account",   modal.accountId ?? "—"],
              ["Triggered", modal.detail ?? "Approval threshold"],
            ].map(([k,v]) => (
              <div key={k} style={{ display:"flex",justifyContent:"space-between",padding:"9px 0",
                borderBottom:`1px solid ${T.border}`,fontSize:13 }}>
                <span style={{ color:T.muted }}>{k}</span>
                <span style={{ color: k==="Amount" ? T.amber : T.text,
                  fontFamily: k==="Account" ? "var(--mono)" : "inherit",
                  fontSize: k==="Account" ? 11 : 13, fontWeight: k==="Amount" ? 700 : 400 }}>{v}</span>
              </div>
            ))}
            <div style={{ display:"flex",gap:10,marginTop:22 }}>
              <button onClick={handleReject} style={{ flex:1,padding:12,borderRadius:9,
                background:T.surface2,border:`1px solid ${T.border2}`,color:T.muted,fontSize:14,fontWeight:600,
                transition:"all .15s" }}>Reject</button>
              <button onClick={handleApprove} style={{ flex:1,padding:12,borderRadius:9,
                background:T.green,border:"none",color:"#04070d",fontSize:14,fontWeight:800,
                transition:"opacity .15s" }}>Approve ✓</button>
            </div>
          </div>
        </div>
      )}

      {/* ── ROOT ── */}
      <div style={{ display:"grid",gridTemplateRows:"60px 1fr",height:"100vh",position:"relative",zIndex:1 }}>

        {/* Header */}
        <header style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
          padding:"0 22px",borderBottom:`1px solid ${T.border}`,
          background:"rgba(4,7,13,.88)",backdropFilter:"blur(16px)" }}>
          <div style={{ display:"flex",alignItems:"center",gap:11 }}>
            <div style={{ width:34,height:34,borderRadius:8,fontSize:18,
              background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:`0 0 18px ${T.hedera}66`,animation:"glow 3s ease-in-out infinite" }}>ℏ</div>
            <div>
              <div style={{ fontFamily:"var(--mono)",fontSize:13,fontWeight:700,letterSpacing:".04em" }}>
                Hedera Policy Agent
              </div>
              <div style={{ fontSize:10,color:T.muted,letterSpacing:".1em",textTransform:"uppercase" }}>
                Week 5 Bounty · Hedera Agent Kit v3.8
              </div>
            </div>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            {modal && (
              <button onClick={() => {}} style={{ fontFamily:"var(--mono)",fontSize:10,padding:"4px 12px",
                borderRadius:5,border:`1px solid ${T.amber}`,background:`${T.amber}15`,color:T.amber,
                animation:"pulse 1.2s infinite" }}>
                ⏳ 1 PENDING
              </button>
            )}
            <div style={{ width:7,height:7,borderRadius:"50%",background:T.green,
              boxShadow:`0 0 8px ${T.green}`,animation:"pulse 2.5s infinite" }} />
            <span style={{ fontFamily:"var(--mono)",fontSize:10,color:T.green,padding:"3px 10px",
              borderRadius:4,background:`${T.green}10`,border:`1px solid ${T.green}25` }}>TESTNET</span>
            <span style={{ fontFamily:"var(--mono)",fontSize:10,color:T.muted }}>0.0.1234567</span>
          </div>
        </header>

        {/* 3-col main */}
        <div style={{ display:"grid",gridTemplateColumns:"310px 1fr 270px",overflow:"hidden" }}>

          {/* ── LEFT: Policy Config ── */}
          <aside style={{ borderRight:`1px solid ${T.border}`,overflowY:"auto",padding:16,
            display:"flex",flexDirection:"column",gap:12 }}>

            <PanelTitle color={T.accent}>Policy Configuration</PanelTitle>

            {/* Token */}
            <div>
              <FieldLabel>Payment Token</FieldLabel>
              <div style={{ display:"flex",gap:6 }}>
                {["HBAR","USDC"].map(t => (
                  <button key={t} onClick={() => setToken(t)}
                    style={{ flex:1,padding:"7px 0",borderRadius:7,fontSize:12,fontWeight:700,
                      fontFamily:"var(--mono)",transition:"all .15s",
                      border:`1px solid ${token===t ? (t==="HBAR" ? T.hedera2 : T.accent) : T.border}`,
                      background: token===t ? `${t==="HBAR" ? T.hedera : T.accent}18` : T.surface2,
                      color: token===t ? (t==="HBAR" ? T.hedera2 : T.accent) : T.muted }}>
                    {t === "HBAR" ? "ℏ HBAR" : "＄USDC"}
                  </button>
                ))}
              </div>
            </div>

            {/* Policy toggles */}
            <Card>
              <FieldLabel>Active Policies</FieldLabel>
              {[
                { key:"spendLimit",        label:"Spend Limit",          desc:`Daily ${token} cap enforcement` },
                { key:"allowlist",         label:"Counterparty Allowlist", desc:"Only pay approved accounts" },
                { key:"approvalThreshold", label:"Human Approval",        desc:"Gate high-value HBAR transfers" },
                { key:"anomalyDetection",  label:"Anomaly Detection",     desc:"Flag suspicious patterns" },
              ].map(({ key, label, desc }) => (
                <div key={key} style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
                  padding:"10px 0",borderBottom:`1px solid ${T.border}` }}>
                  <div>
                    <div style={{ fontSize:13,fontWeight:600 }}>{label}</div>
                    <div style={{ fontSize:11,color:T.muted,marginTop:1 }}>{desc}</div>
                  </div>
                  <Toggle
                    on={policies[key].enabled}
                    onChange={() => setPolicies(p => ({ ...p, [key]: { ...p[key], enabled: !p[key].enabled } }))}
                  />
                </div>
              ))}
            </Card>

            {/* Spend cap slider */}
            {policies.spendLimit.enabled && (
              <Card>
                <FieldLabel>Daily Cap — {token}</FieldLabel>
                <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,color:T.muted,marginBottom:6 }}>
                  <span>0</span>
                  <span style={{ color:T.accent,fontFamily:"var(--mono)",fontWeight:700 }}>
                    {policies.spendLimit[token==="HBAR"?"hbar":"usdc"]} {token}
                  </span>
                  <span>1000</span>
                </div>
                <input type="range" min={50} max={1000} step={50}
                  value={policies.spendLimit[token==="HBAR"?"hbar":"usdc"]}
                  onChange={e => setPolicies(p => ({ ...p, spendLimit: { ...p.spendLimit,
                    [token==="HBAR"?"hbar":"usdc"]: Number(e.target.value) } }))}
                  style={{ width:"100%",accentColor:T.accent }} />
              </Card>
            )}

            {/* Approval threshold slider */}
            {policies.approvalThreshold.enabled && (
              <Card>
                <FieldLabel>Approval Threshold (HBAR)</FieldLabel>
                <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,color:T.muted,marginBottom:6 }}>
                  <span>10</span>
                  <span style={{ color:T.amber,fontFamily:"var(--mono)",fontWeight:700 }}>
                    {policies.approvalThreshold.hbar} HBAR
                  </span>
                  <span>500</span>
                </div>
                <input type="range" min={10} max={500} step={10}
                  value={policies.approvalThreshold.hbar}
                  onChange={e => setPolicies(p => ({ ...p, approvalThreshold: { ...p.approvalThreshold,
                    hbar: Number(e.target.value) } }))}
                  style={{ width:"100%",accentColor:T.amber }} />
              </Card>
            )}

            {/* Allowlist */}
            {policies.allowlist.enabled && (
              <Card>
                <FieldLabel>Approved Counterparties</FieldLabel>
                {policies.allowlist.accounts.map(acc => {
                  const svc = SERVICES[acc];
                  return (
                    <div key={acc} style={{ display:"flex",alignItems:"center",gap:8,
                      padding:"7px 10px",background:T.surface2,border:`1px solid ${T.border}`,
                      borderRadius:7,marginBottom:5,fontSize:11 }}>
                      <span style={{ fontSize:15 }}>{svc?.icon ?? "🏢"}</span>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ color:T.text,fontWeight:600,fontSize:12 }}>{svc?.name ?? acc}</div>
                        <div style={{ color:T.muted,fontFamily:"var(--mono)",fontSize:9,marginTop:1 }}>{acc}</div>
                      </div>
                      <button onClick={() => setPolicies(p => ({ ...p,
                          allowlist: { ...p.allowlist, accounts: p.allowlist.accounts.filter(a => a !== acc) } }))}
                        style={{ background:"none",color:T.muted,fontSize:16,lineHeight:1,padding:"0 2px",
                          transition:"color .15s",borderRadius:3 }}>×</button>
                    </div>
                  );
                })}
                {Object.keys(SERVICES).filter(a => !policies.allowlist.accounts.includes(a)).length > 0 && (
                  <button onClick={() => {
                    const unused = Object.keys(SERVICES).find(a => !policies.allowlist.accounts.includes(a));
                    if (unused) setPolicies(p => ({ ...p,
                      allowlist: { ...p.allowlist, accounts: [...p.allowlist.accounts, unused] } }));
                  }} style={{ width:"100%",padding:8,borderRadius:7,border:`1px dashed ${T.border2}`,
                    background:"none",color:T.muted,fontSize:12,transition:"all .15s" }}>
                    + Add service
                  </button>
                )}
              </Card>
            )}

            {/* Code snippet */}
            <div>
              <FieldLabel>Hook Pattern (src/hooks/)</FieldLabel>
              <div style={{ background:"#020509",border:`1px solid ${T.border}`,borderRadius:8,
                padding:12,fontFamily:"var(--mono)",fontSize:10,color:"#7dd3fc",lineHeight:1.8,
                overflow:"hidden",whiteSpace:"pre" }}>
<span style={{color:T.muted}}>{"// policyEngine.ts\n"}</span>
<span style={{color:T.hedera2}}>{"export function "}</span>
<span style={{color:T.accent}}>{"evaluate"}</span>
{"(req, cfg) {\n"}
{"  const violations = [\n"}
{"    "}
<span style={{color:"#86efac"}}>{"checkAllowlist"}</span>
{"(req, cfg),\n"}
{"    "}
<span style={{color:"#86efac"}}>{"checkAnomaly"}</span>
{"(req, cfg),\n"}
{"    "}
<span style={{color:"#86efac"}}>{"checkApproval"}</span>
{"(req, cfg),\n"}
{"    "}
<span style={{color:"#86efac"}}>{"checkSpendLimit"}</span>
{"(req, cfg),\n"}
{"  ].filter(Boolean);\n"}
<span style={{color:T.hedera2}}>{"  return "}</span>
{"violations.length\n"}
{"    ? { decision: "}
<span style={{color:"#fca5a5"}}>{'"blocked"'}</span>
{" }\n"}
{"    : { decision: "}
<span style={{color:"#86efac"}}>{'"approved"'}</span>
{" };\n}"}
              </div>
            </div>
          </aside>

          {/* ── CENTER: Chat ── */}
          <div style={{ display:"flex",flexDirection:"column",overflow:"hidden" }}>

            {/* Chat header */}
            <div style={{ padding:"12px 18px",borderBottom:`1px solid ${T.border}`,
              display:"flex",alignItems:"center",gap:12 }}>
              <div style={{ width:40,height:40,borderRadius:"50%",flexShrink:0,
                background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,
                boxShadow:`0 0 20px ${T.hedera}66` }}>🤖</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:14,fontWeight:700 }}>Policy Agent</div>
                <div style={{ fontSize:11,color:T.green }}>● Online · Hedera Testnet · Claude Sonnet</div>
              </div>
              {busy && (
                <div style={{ display:"flex",alignItems:"center",gap:7,fontFamily:"var(--mono)",fontSize:10,
                  color:T.amber,background:`${T.amber}12`,border:`1px solid ${T.amber}30`,
                  padding:"4px 12px",borderRadius:5 }}>
                  <div style={{ width:10,height:10,border:`2px solid ${T.amber}`,borderTopColor:"transparent",
                    borderRadius:"50%",animation:"spin .8s linear infinite" }} />
                  EVALUATING
                </div>
              )}
            </div>

            {/* Presets */}
            <div style={{ padding:"8px 16px",borderBottom:`1px solid ${T.border}`,
              display:"flex",gap:6,flexWrap:"wrap" }}>
              {PRESETS.map(p => (
                <button key={p.label} onClick={() => !busy && send(p.msg)} disabled={busy}
                  style={{ fontSize:11,padding:"4px 12px",borderRadius:20,
                    border:`1px solid ${T.border2}`,background:T.surface2,color:T.muted,
                    whiteSpace:"nowrap",transition:"all .15s",
                    opacity: busy ? .5 : 1 }}>
                  {p.label}
                </button>
              ))}
            </div>

            {/* Messages */}
            <div ref={msgsRef} style={{ flex:1,overflowY:"auto",padding:"18px 18px",
              display:"flex",flexDirection:"column",gap:11 }}>
              {messages.map(m => {
                if (m.role === "policy") {
                  const c = m.policyType === "approved" ? T.green : m.policyType === "blocked" ? T.red : T.amber;
                  return (
                    <div key={m.id} className="fadeup" style={{ alignSelf:"center",display:"flex",flexDirection:"column",
                      alignItems:"center",gap:3,maxWidth:"85%" }}>
                      <div style={{ background:`${c}0e`,border:`1px solid ${c}33`,borderRadius:7,
                        padding:"6px 16px",fontSize:11,color:c,fontFamily:"var(--mono)",fontWeight:500,
                        letterSpacing:".06em" }}>
                        {m.text}
                      </div>
                      {m.detail && (
                        <div style={{ fontSize:10,color:T.muted,textAlign:"center",maxWidth:360 }}>{m.detail}</div>
                      )}
                    </div>
                  );
                }
                const isUser = m.role === "user";
                return (
                  <div key={m.id} className="fadeup" style={{ alignSelf: isUser ? "flex-end" : "flex-start", maxWidth:"84%" }}>
                    <div style={{ padding:"11px 15px",lineHeight:1.65,fontSize:13,
                      borderRadius: isUser ? "14px 14px 3px 14px" : "14px 14px 14px 3px",
                      background: isUser ? `linear-gradient(135deg,${T.hedera},${T.accent2})` : T.surface,
                      border: isUser ? "none" : `1px solid ${T.border2}`,
                      color: T.text }}>
                      {m.text}
                      {m.card && m.card.amount > 0 && (
                        <div style={{ background:T.surface2,border:`1px solid ${T.border}`,borderRadius:8,
                          padding:11,marginTop:10,fontFamily:"var(--mono)",fontSize:11 }}>
                          {[
                            ["Status", m.card.decision==="approved" ? "✓ EXECUTED" : "✗ BLOCKED",
                              m.card.decision==="approved" ? T.green : T.red],
                            ["Amount", `${m.card.amount} ${m.card.currency}`, T.text],
                            ["To",     m.card.service ?? m.card.accountId, T.text],
                            ...(m.card.hash ? [["TX Hash", shortHash(m.card.hash), T.muted]] : []),
                          ].map(([k,v,c]) => (
                            <div key={k} style={{ display:"flex",justifyContent:"space-between",
                              padding:"4px 0",borderBottom:`1px solid ${T.border}`,fontSize:10 }}>
                              <span style={{ color:T.muted }}>{k}</span>
                              <span style={{ color:c,fontWeight: k==="Status"||k==="Amount" ? 700 : 400 }}>{v}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div style={{ fontSize:10,color:T.muted,marginTop:3,padding:"0 4px",
                      textAlign: isUser ? "right" : "left" }}>{m.time}</div>
                  </div>
                );
              })}
              {busy && (
                <div className="fadeup" style={{ alignSelf:"flex-start",padding:"11px 16px",
                  borderRadius:"14px 14px 14px 3px",background:T.surface,border:`1px solid ${T.border2}`,
                  fontSize:13,color:T.muted,display:"flex",gap:8,alignItems:"center" }}>
                  <div style={{ display:"flex",gap:3 }}>
                    {[0,1,2].map(i => (
                      <div key={i} style={{ width:5,height:5,borderRadius:"50%",background:T.muted,
                        animation:`pulse 1.2s ${i*.2}s infinite` }} />
                    ))}
                  </div>
                  Checking policies…
                </div>
              )}
            </div>

            {/* Input */}
            <div style={{ padding:"13px 16px",borderTop:`1px solid ${T.border}`,
              display:"flex",gap:9,alignItems:"flex-end" }}>
              <textarea ref={inputRef} value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()} }}
                placeholder={`e.g. "Pay 50 HBAR to OpenAI for API credits"`}
                rows={1}
                style={{ flex:1,background:T.surface,border:`1px solid ${T.border2}`,borderRadius:9,
                  color:T.text,fontSize:13,padding:"10px 14px",resize:"none",
                  minHeight:42,maxHeight:110,transition:"border-color .15s",
                  lineHeight:1.5 }} />
              <button onClick={() => send()} disabled={busy || !input.trim()}
                style={{ padding:"0 20px",background:`linear-gradient(135deg,${T.hedera},${T.accent})`,
                  borderRadius:9,color:"white",fontSize:13,fontWeight:700,height:42,flexShrink:0,
                  opacity: busy||!input.trim() ? .4 : 1,transition:"opacity .15s" }}>
                Send ↑
              </button>
            </div>
          </div>

          {/* ── RIGHT: Ledger ── */}
          <aside style={{ borderLeft:`1px solid ${T.border}`,overflowY:"auto",padding:16,
            display:"flex",flexDirection:"column",gap:12 }}>

            <PanelTitle color={T.green}>Spend Tracker</PanelTitle>

            {/* Spend meter */}
            <Card>
              <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,
                color:T.muted,marginBottom:8 }}>
                <span>Daily Usage</span>
                <span style={{ color: overWarn ? T.amber : T.green,
                  fontFamily:"var(--mono)",fontWeight:700 }}>
                  {spendVal.toFixed(1)} / {spendCap} {token}
                </span>
              </div>
              <div style={{ height:5,background:T.faint,borderRadius:3,overflow:"hidden" }}>
                <div style={{ height:"100%",width:`${spendPct}%`,borderRadius:3,transition:"width .6s ease",
                  background: overWarn
                    ? `linear-gradient(90deg,${T.amber},${T.red})`
                    : `linear-gradient(90deg,${T.green},${T.accent})` }} />
              </div>
              <div style={{ display:"flex",justifyContent:"space-between",marginTop:7,fontSize:10,color:T.muted }}>
                <span>{spendPct.toFixed(0)}% used</span>
                <span>Resets in 24h</span>
              </div>
            </Card>

            {/* Counters */}
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
              <MiniStat label="Sent" value={sentCount}  color={T.green} />
              <MiniStat label="Blocked" value={blockCount} color={T.red} />
            </div>

            {/* HBAR + USDC totals */}
            <Card>
              <FieldLabel>Today's Outflow</FieldLabel>
              {[
                { label:"HBAR", val:spendState.hbar, cap:policies.spendLimit.hbar, color:T.hedera2 },
                { label:"USDC", val:spendState.usdc, cap:policies.spendLimit.usdc, color:T.accent },
              ].map(({ label, val, cap, color }) => (
                <div key={label} style={{ display:"flex",justifyContent:"space-between",
                  padding:"7px 0",borderBottom:`1px solid ${T.border}`,fontSize:12 }}>
                  <span style={{ fontFamily:"var(--mono)",color }}>{label}</span>
                  <span style={{ fontFamily:"var(--mono)",fontWeight:600,color:T.text }}>
                    {val.toFixed(1)}
                    <span style={{ color:T.muted,fontWeight:400 }}> / {cap}</span>
                  </span>
                </div>
              ))}
            </Card>

            <PanelTitle color={T.accent}>Transaction Log</PanelTitle>

            {txLog.length === 0 && (
              <div style={{ color:T.muted,fontSize:12,textAlign:"center",padding:"20px 0",fontStyle:"italic" }}>
                No transactions yet
              </div>
            )}

            <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
              {txLog.map(tx => (
                <div key={tx.id} style={{ background:T.surface,border:`1px solid ${T.border}`,
                  borderRadius:9,padding:11,transition:"border-color .15s" }}>
                  <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6 }}>
                    <span style={{ fontFamily:"var(--mono)",fontSize:11,color:T.accent,fontWeight:600,
                      maxWidth:130,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>
                      {tx.service}
                    </span>
                    <span style={{ fontSize:10,padding:"2px 8px",borderRadius:10,fontWeight:600,
                      background: tx.status==="ok" ? `${T.green}18` : `${T.red}18`,
                      color: tx.status==="ok" ? T.green : T.red }}>
                      {tx.status==="ok" ? "Sent" : "Blocked"}
                    </span>
                  </div>
                  <div style={{ fontFamily:"var(--mono)",fontWeight:700,fontSize:14,marginBottom:4 }}>
                    {tx.amount}{" "}
                    <span style={{ fontSize:10,padding:"2px 7px",borderRadius:4,fontWeight:500,
                      background: tx.currency==="HBAR" ? `${T.hedera}25` : `${T.accent}15`,
                      color: tx.currency==="HBAR" ? T.hedera2 : T.accent,
                      border:`1px solid ${tx.currency==="HBAR" ? T.hedera2 : T.accent}30` }}>
                      {tx.currency}
                    </span>
                  </div>
                  <div style={{ fontSize:10,color:T.muted }}>{tx.time}</div>
                  {tx.hash && (
                    <div style={{ fontFamily:"var(--mono)",fontSize:9,color:T.faint,
                      marginTop:5,wordBreak:"break-all" }}>{shortHash(tx.hash)}</div>
                  )}
                  {tx.policy && (
                    <div style={{ marginTop:4,fontSize:10,color:T.amber }}>
                      ⚡ {tx.policy.replace("_"," ")} policy
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Links */}
            <div style={{ marginTop:4,padding:12,background:T.surface2,border:`1px solid ${T.border}`,
              borderRadius:9,fontSize:11 }}>
              <div style={{ color:T.muted,marginBottom:8,fontSize:10,letterSpacing:".1em",
                textTransform:"uppercase" }}>Resources</div>
              {[
                ["Agent Kit JS",   "https://github.com/hashgraph/hedera-agent-kit-js"],
                ["AI Bounties",    "https://ai-bounties.hedera.com"],
                ["Get Testnet Acc","https://portal.hedera.com/dashboard"],
                ["AI Studio Docs", "https://docs.hedera.com/hedera/open-source-solutions/ai-studio-on-hedera"],
              ].map(([label,url]) => (
                <a key={label} href={url} target="_blank" rel="noreferrer"
                  style={{ display:"block",color:T.accent,fontSize:11,marginBottom:4,
                    fontFamily:"var(--mono)",textDecoration:"none" }}>
                  → {label}
                </a>
              ))}
            </div>
          </aside>

        </div>
      </div>
    </>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────
function PanelTitle({ children, color }) {
  return (
    <div style={{ display:"flex",alignItems:"center",gap:8,fontFamily:"var(--mono)",fontSize:10,
      letterSpacing:".14em",textTransform:"uppercase",color:T.muted,
      paddingBottom:10,borderBottom:`1px solid ${T.border}` }}>
      <div style={{ width:6,height:6,borderRadius:"50%",background:color,flexShrink:0,
        boxShadow:`0 0 6px ${color}` }} />
      {children}
    </div>
  );
}

function FieldLabel({ children }) {
  return (
    <div style={{ fontSize:10,letterSpacing:".1em",textTransform:"uppercase",
      color:T.muted,marginBottom:8 }}>{children}</div>
  );
}

function Card({ children }) {
  return (
    <div style={{ background:T.surface,border:`1px solid ${T.border}`,borderRadius:10,padding:14 }}>
      {children}
    </div>
  );
}

function Toggle({ on, onChange }) {
  return (
    <button onClick={onChange}
      style={{ width:36,height:20,borderRadius:10,flexShrink:0,marginLeft:12,
        background: on ? T.green : T.faint,border:"none",position:"relative",
        transition:"background .2s",cursor:"pointer" }}>
      <span style={{ position:"absolute",top:2,width:16,height:16,borderRadius:"50%",
        background:"white",transition:"left .2s",
        left: on ? 18 : 2 }} />
    </button>
  );
}

function MiniStat({ label, value, color }) {
  return (
    <div style={{ background:T.surface,border:`1px solid ${T.border}`,borderRadius:10,padding:"12px 14px" }}>
      <div style={{ fontSize:10,letterSpacing:".1em",textTransform:"uppercase",color:T.muted,marginBottom:6 }}>
        {label}
      </div>
      <div style={{ fontFamily:"var(--mono)",fontSize:24,fontWeight:700,color,lineHeight:1 }}>{value}</div>
    </div>
  );
}
