import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  define: {
    // WalletConnect needs global
    global: "globalThis",
  },
  resolve: {
    alias: {
      // Buffer polyfill for WalletConnect in browser
      buffer: "buffer/",
    },
  },
  optimizeDeps: {
    include: ["buffer"],
    esbuildOptions: {
      define: { global: "globalThis" },
    },
  },
  server: {
    proxy: {
      "/api": "http://localhost:3001",
    },
  },
});
