#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# push-to-github.sh
# Run this script from inside the xpay/ folder.
# It will initialise git, create the GitHub repo (via gh CLI or curl),
# and push everything in one shot.
#
# Usage:
#   chmod +x push-to-github.sh
#   ./push-to-github.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e

REPO_NAME="xpay"
DESCRIPTION="AI payment agent with runtime policy enforcement (spend limits, allowlists, human approval) on Hedera — Week 5 Bounty"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║     xPay — GitHub Push Script         ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── Step 1: git init ─────────────────────────────────────────────────────────
if [ ! -d ".git" ]; then
  echo "▶ Initialising git..."
  git init
  git branch -M main
else
  echo "✓ Git already initialised"
fi

# ── Step 2: configure git identity if not set ────────────────────────────────
if [ -z "$(git config user.email)" ]; then
  echo ""
  read -rp "  Enter your GitHub email: " GIT_EMAIL
  read -rp "  Enter your name: " GIT_NAME
  git config user.email "$GIT_EMAIL"
  git config user.name "$GIT_NAME"
fi

# ── Step 3: stage everything ─────────────────────────────────────────────────
echo ""
echo "▶ Staging all files..."
git add -A
git status --short

# ── Step 4: initial commit ───────────────────────────────────────────────────
echo ""
echo "▶ Creating initial commit..."
git commit -m "feat: xPay — Week 5 Bounty Submission

- 4 policy hooks: spend limit, allowlist, approval threshold, anomaly detection
- LangGraph agent with policy-gated transfer_payment tool
- Hedera Agent Kit (HederaLangchainToolkit + TransferTransaction)
- React/Vite frontend with 3-panel UI and human approval modal
- Express REST API with 8 endpoints
- Docker + GitHub Actions CI
- 12 unit tests (Vitest)
- Deploy guides for Railway, Render, Fly.io

Supports HBAR and USDC payments on Hedera testnet/mainnet." || echo "  (nothing new to commit)"

# ── Step 5: create GitHub repo ───────────────────────────────────────────────
echo ""
echo "▶ Creating GitHub repository..."

# Try gh CLI first (recommended)
if command -v gh &> /dev/null; then
  echo "  Using GitHub CLI..."
  gh repo create "$REPO_NAME" \
    --public \
    --description "$DESCRIPTION" \
    --source=. \
    --remote=origin \
    --push
  echo ""
  echo "✅ Done! Repo URL:"
  gh repo view --json url -q .url

else
  # Fall back to curl + personal access token
  echo "  GitHub CLI not found — using API token method."
  echo ""
  read -rp "  Enter your GitHub username: " GH_USER
  read -rsp "  Enter your GitHub Personal Access Token (repo scope): " GH_TOKEN
  echo ""

  # Create repo via API
  RESPONSE=$(curl -s -w "\n%{http_code}" \
    -H "Authorization: token $GH_TOKEN" \
    -H "Accept: application/vnd.github.v3+json" \
    https://api.github.com/user/repos \
    -d "{\"name\":\"$REPO_NAME\",\"description\":\"$DESCRIPTION\",\"private\":false}")

  HTTP_CODE=$(echo "$RESPONSE" | tail -1)
  BODY=$(echo "$RESPONSE" | head -n -1)

  if [ "$HTTP_CODE" = "201" ]; then
    REPO_URL="https://github.com/$GH_USER/$REPO_NAME"
    echo "  ✓ Repository created: $REPO_URL"
    git remote add origin "https://$GH_USER:$GH_TOKEN@github.com/$GH_USER/$REPO_NAME.git" 2>/dev/null || \
    git remote set-url origin "https://$GH_USER:$GH_TOKEN@github.com/$GH_USER/$REPO_NAME.git"
  elif [ "$HTTP_CODE" = "422" ]; then
    echo "  ℹ Repo may already exist — attempting to connect..."
    read -rp "  Enter your GitHub username: " GH_USER_2
    GH_USER="${GH_USER:-$GH_USER_2}"
    git remote add origin "https://$GH_USER:$GH_TOKEN@github.com/$GH_USER/$REPO_NAME.git" 2>/dev/null || \
    git remote set-url origin "https://$GH_USER:$GH_TOKEN@github.com/$GH_USER/$REPO_NAME.git"
  else
    echo "  ✗ API returned HTTP $HTTP_CODE"
    echo "$BODY" | python3 -c "import sys,json; d=json.load(sys.stdin); print('  Error:', d.get('message','unknown'))" 2>/dev/null || echo "$BODY"
    echo ""
    echo "  Manual fallback — create the repo at https://github.com/new"
    echo "  then run: git remote add origin https://github.com/YOUR_USER/$REPO_NAME.git"
    exit 1
  fi

  echo "▶ Pushing to GitHub..."
  git push -u origin main
  echo ""
  echo "✅ Done! Repo URL: https://github.com/$GH_USER/$REPO_NAME"
fi

echo ""
echo "─────────────────────────────────────────────────────"
echo "  Next steps:"
echo "  1. Deploy to Railway (see docs/DEPLOYMENT.md)"
echo "  2. File feedback at github.com/hashgraph/hedera-agent-kit-js"
echo "  3. Submit at ai-bounties.hedera.com/#submit"
echo "     (copy your text from docs/SUBMISSION.md)"
echo "  4. Deadline: Sunday June 21, 23:59 UTC"
echo "─────────────────────────────────────────────────────"
echo ""
