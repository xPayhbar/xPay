# ℏ xPay

> **Week 5 Bounty Submission — $1,500 HBAR**  
> Policy-constrained AI agent payments in HBAR and USDC on Hedera

[![Live Demo](https://img.shields.io/badge/demo-live-00e5a0?style=flat-square)](https://YOUR_DEPLOY_URL)
[![Hedera Agent Kit](https://img.shields.io/badge/hedera--agent--kit-v3.8.x-6d28d9?style=flat-square)](https://github.com/hashgraph/hedera-agent-kit-js)
[![License](https://img.shields.io/badge/license-Apache--2.0-blue?style=flat-square)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-passing-00e5a0?style=flat-square)](#testing)

An autonomous AI payment agent built on the **Hedera Agent Kit** that enforces runtime policies before executing any on-chain HBAR or USDC transfer. The policy layer is composable, configurable at runtime, and always visible in the UI — so agents can purchase real services while remaining constrained within defined guardrails.

![Screenshot](docs/screenshot.png)

---

## What It Does

The agent accepts natural-language payment instructions:

> *"Pay 50 HBAR to OpenAI for API credits"*  
> *"Transfer 20 USDC to Pinecone DB for vector storage"*  
> *"Send 300 HBAR to Twilio for an SMS campaign"*

Before any funds move, every request passes through a **policy engine** with four hooks:

| Hook | What it enforces |
|------|-----------------|
| 🚫 **Spend Limit** | 24-hour rolling cap on HBAR and USDC outflows |
| 🚫 **Counterparty Allowlist** | Only pay pre-approved Hedera accounts |
| ⏳ **Human Approval** | Gate transfers above a configurable HBAR threshold |
| ⚠️ **Anomaly Detection** | Flag unknown recipients and suspicious amounts |

---

## Architecture

```
User (browser)
    │  natural language
    ▼
React Frontend (Vite)
    │  POST /api/chat
    ▼
Express API  ──────────────────────────────────────────────────────────────┐
    │                                                                       │
    ▼                                                                       │
LangGraph Agent (createReactAgent)                                         │
    │  calls transfer_payment tool                                          │
    ▼                                                                       │
Policy Engine                                                              │
    ├─ allowlistHook.ts    → block unknown counterparties                   │
    ├─ anomalyHook.ts      → flag suspicious patterns                       │
    ├─ approvalHook.ts     → pause for human sign-off                       │
    └─ spendLimitHook.ts   → enforce daily cap                              │
         │ approved                                                         │
         ▼                                                                  │
Hedera Agent Kit (HederaLangchainToolkit)                                  │
    │  TransferTransaction (HBAR) / HTS TokenTransfer (USDC)               │
    ▼                                                                       │
Hedera Testnet / Mainnet ◄─────────────────────────────────────────────────┘
```

---

## Quick Start

### Prerequisites
- Node.js 20+
- A Hedera testnet account — [get one free](https://portal.hedera.com/dashboard)
- An Anthropic API key — [get one](https://console.anthropic.com)

### 1. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/xpay
cd xpay
npm install
cd frontend && npm install && cd ..
```

### 2. Configure

```bash
cp .env.example .env
```

Edit `.env`:

```env
HEDERA_ACCOUNT_ID=0.0.XXXXX
HEDERA_PRIVATE_KEY=0x...
HEDERA_NETWORK=testnet
ANTHROPIC_API_KEY=sk-ant-...
```

### 3. Run

```bash
npm run dev
```

- **Frontend**: http://localhost:5173
- **API**: http://localhost:3001/api

---

## Policy Hooks

Each hook is a pure TypeScript function in `src/hooks/`:

```typescript
// src/hooks/spendLimitHook.ts
export function checkSpendLimit(
  request: TransferRequest,
  config: PolicyConfig
): PolicyViolation | null {
  if (!config.spendLimit.enabled) return null;

  const limit = request.currency === "HBAR"
    ? config.spendLimit.hbar
    : config.spendLimit.usdc;
  const current = getSpendState()[request.currency === "HBAR" ? "hbar" : "usdc"];

  if (current + request.amount > limit) {
    return {
      policy: "spend_limit",
      reason: `Daily ${request.currency} spend limit exceeded`,
      detail: `Limit: ${limit} | Used: ${current} | Requested: ${request.amount}`,
    };
  }
  return null;
}
```

The **policy engine** (`src/policyEngine.ts`) runs all hooks in order and derives a final decision:

```typescript
export function evaluatePolicy(request, config): PolicyResult {
  const violations = [
    checkAllowlist(request, config),
    checkAnomaly(request, config),
    checkApprovalThreshold(request, config),
    checkSpendLimit(request, config),
  ].filter(Boolean);

  if (violations.length === 0) return { decision: "approved", ... };

  const hasHardBlock = violations.some(v =>
    v.policy === "spend_limit" || v.policy === "allowlist"
  );

  return hasHardBlock
    ? { decision: "blocked", violations, ... }
    : { decision: "needs_approval", violations, ... };
}
```

---

## Hedera Agent Kit Integration

The agent is built with `HederaLangchainToolkit` in `AgentMode.AUTONOMOUS`:

```typescript
// src/hederaClient.ts
const client = Client.forTestnet().setOperator(
  AccountId.fromString(process.env.HEDERA_ACCOUNT_ID!),
  PrivateKey.fromStringECDSA(process.env.HEDERA_PRIVATE_KEY!)
);

const toolkit = new HederaLangchainToolkit({
  client,
  configuration: {
    tools: [],
    plugins: [],
    context: { mode: AgentMode.AUTONOMOUS },
  },
});
```

HBAR transfers execute via the Hedera SDK `TransferTransaction` after policy clearance:

```typescript
const tx = await new TransferTransaction()
  .addHbarTransfer(operatorId, Hbar.fromTinybars(-amount))
  .addHbarTransfer(toId, Hbar.fromTinybars(amount))
  .setTransactionMemo(`xPay: ${serviceName}`)
  .execute(client);
```

---

## API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Send a message to the agent |
| `/api/spend` | GET | Get today's spend totals |
| `/api/spend/reset` | POST | Reset the spend window |
| `/api/pending` | GET | List transactions awaiting approval |
| `/api/approve/:id` | POST | Human-approve a pending transaction |
| `/api/reject/:id` | POST | Reject a pending transaction |
| `/api/policy` | GET | Get current policy configuration |
| `/api/health` | GET | Health check |

---

## Testing

```bash
npm test
```

Tests cover all four policy hooks and their combinations:

```
✓ approves a transfer within the daily cap
✓ blocks a transfer that exceeds the daily cap
✓ passes when spend limit policy is disabled
✓ tracks USDC separately from HBAR
✓ approves a transfer to an allowlisted account
✓ blocks a transfer to an unknown account
✓ requires approval at or above threshold
✓ does not gate USDC transfers
✓ flags unknown recipient accounts
✓ flags absurdly large payments
✓ returns all violations, not just the first
✓ decision is blocked if any hard-block policy fires
```

---

## Deployment

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for step-by-step guides for:
- **Railway** (recommended — one-click Docker deploy)
- **Render**
- **Fly.io**

---

## Bounty Requirements Checklist

- [x] Public GitHub repository
- [x] Built using Hedera Agent Kit JS (v3.8.x)
- [x] Uses `HederaLangchainToolkit` + `TransferTransaction`
- [x] Policy hooks clearly integrated: spend limit, allowlist, approval, anomaly
- [x] Payments in HBAR and USDC
- [x] Human-in-the-loop flow for mainnet safety
- [x] Live demo URL (stays up 90+ days — see deployment guide)
- [x] Feedback submitted to Hedera Agent Kit repo
- [x] Week 5 submission form completed

---

## License

Apache-2.0 — see [LICENSE](LICENSE)

---

## Resources

- [Hedera Agent Kit JS](https://github.com/hashgraph/hedera-agent-kit-js)
- [AI Studio Docs](https://docs.hedera.com/hedera/open-source-solutions/ai-studio-on-hedera)
- [Hedera AI Bounties](https://ai-bounties.hedera.com)
- [Submit Feedback](https://github.com/hashgraph/hedera-agent-kit-js/issues/new?template=agent_kit_feedback.yml)
- [Discord Office Hours](https://hedera.com/discord)

---

## WalletConnect Integration

The agent supports signing transactions directly from the user's Hedera wallet via **WalletConnect 2.0** (HIP-820 standard), using the official `@hashgraph/hedera-wallet-connect` package.

### Supported Wallets
| Wallet | Type | Connect via |
|--------|------|-------------|
| **HashPack** | Hedera native | WalletConnect QR / deep link |
| **Blade** | Hedera native | WalletConnect QR |
| **Kabila** | Hedera native | WalletConnect QR |
| **MetaMask** | EVM-compatible | WalletConnect QR |

### How it works
Without wallet: agent uses the server-side keypair (`HEDERA_PRIVATE_KEY`) to sign. Fine for testnet demos.

With wallet connected: when a transfer reaches the approval modal, the frontend calls `signAndExecuteTransfer()` — the transaction bytes are sent to the user's wallet app for signing. **The server never sees the private key.**

```typescript
// frontend/src/wallet/walletConnect.ts
const tx = await new TransferTransaction()
  .addHbarTransfer(fromId, Hbar.fromTinybars(-tinybars))
  .addHbarTransfer(toId,   Hbar.fromTinybars(tinybars))
  .freezeWithSigner(signer);

const result = await connector.signAndExecuteTransaction({
  signerAccountId: `hedera:testnet:${accountId}`,
  transactionList: transactionToBase64String(tx),
});
```

### Setup
1. Get a free WalletConnect project ID at [cloud.walletconnect.com](https://cloud.walletconnect.com)
2. Add it to your `.env`:
   ```
   VITE_WALLETCONNECT_PROJECT_ID=your_project_id
   ```
3. In the deployed app, click **Connect Wallet** in the header
4. Scan the QR code with HashPack, Blade, or Kabila
