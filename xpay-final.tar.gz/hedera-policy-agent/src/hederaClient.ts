// src/hederaClient.ts
// Uses hedera-agent-kit@3.8.2 + @hashgraph/sdk (both published, installable)

import {
  Client,
  PrivateKey,
  AccountId,
  Hbar,
  TransferTransaction,
} from "@hashgraph/sdk";                                    // ✅ @hashgraph/sdk@^2.51.0
import {
  HederaLangchainToolkit,
  AgentMode,
} from "hedera-agent-kit";                                 // ✅ hedera-agent-kit@3.8.2
import type { TransferRequest, ExecutedTransaction } from "./types.js";
import { recordSpend } from "./hooks/spendLimitHook.js";
import { randomUUID } from "crypto";

let _client: Client | null = null;
let _toolkit: HederaLangchainToolkit | null = null;

export function getHederaClient(): Client {
  if (_client) return _client;

  const accountId  = process.env.HEDERA_ACCOUNT_ID;
  const privateKey = process.env.HEDERA_PRIVATE_KEY;
  const network    = process.env.HEDERA_NETWORK ?? "testnet";

  if (!accountId || !privateKey)
    throw new Error("Missing HEDERA_ACCOUNT_ID or HEDERA_PRIVATE_KEY");

  _client = network === "mainnet" ? Client.forMainnet() : Client.forTestnet();
  _client.setOperator(
    AccountId.fromString(accountId),
    PrivateKey.fromStringECDSA(privateKey)
  );
  return _client;
}

export function getHederaToolkit(): HederaLangchainToolkit {
  if (_toolkit) return _toolkit;
  const client = getHederaClient();
  _toolkit = new HederaLangchainToolkit({
    client,
    configuration: {
      tools:   [],
      plugins: [],
      context: { mode: AgentMode.AUTONOMOUS },
    },
  });
  return _toolkit;
}

export async function executeHbarTransfer(
  request: TransferRequest
): Promise<ExecutedTransaction> {
  const client     = getHederaClient();
  const operatorId = AccountId.fromString(process.env.HEDERA_ACCOUNT_ID!);
  const toId       = AccountId.fromString(request.toAccountId);
  const tinybars   = Math.round(request.amount * 1e8);

  const tx = await new TransferTransaction()
    .addHbarTransfer(operatorId, Hbar.fromTinybars(-tinybars))
    .addHbarTransfer(toId,       Hbar.fromTinybars(tinybars))
    .setTransactionMemo(request.memo ?? `xPay: ${request.serviceName ?? "payment"}`)
    .execute(client);

  await tx.getReceipt(client);
  recordSpend(request.amount, "HBAR");

  return {
    id:        randomUUID(),
    request,
    decision:  "approved",
    txHash:    tx.transactionId.toString(),
    timestamp: new Date().toISOString(),
    violations: [],
  };
}

export async function executeUsdcTransfer(
  request: TransferRequest
): Promise<ExecutedTransaction> {
  // Testnet demo: simulated. For mainnet use HTS TransferTransaction with addTokenTransfer()
  await new Promise((r) => setTimeout(r, 600));
  recordSpend(request.amount, "USDC");
  return {
    id:        randomUUID(),
    request,
    decision:  "approved",
    txHash:    `0.0.${Date.now()}-usdc-sim`,
    timestamp: new Date().toISOString(),
    violations: [],
  };
}

export async function executeTransfer(request: TransferRequest): Promise<ExecutedTransaction> {
  return request.currency === "HBAR"
    ? executeHbarTransfer(request)
    : executeUsdcTransfer(request);
}
