// src/server.ts
// Express server — serves the API and the React frontend build

import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import apiRouter from "./routes/api.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT ?? 3001);

// ── Middleware ─────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.NODE_ENV === "production" ? false : "*" }));
app.use(express.json({ limit: "1mb" }));

// ── API routes ─────────────────────────────────────────────────────────────
app.use("/api", apiRouter);

// ── Serve React build in production ────────────────────────────────────────
if (process.env.NODE_ENV === "production") {
  const frontendBuild = path.join(__dirname, "../frontend/dist");
  app.use(express.static(frontendBuild));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(frontendBuild, "index.html"));
  });
}

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🟢 xPay — AI Payment Agent`);
  console.log(`   Network : ${process.env.HEDERA_NETWORK ?? "testnet"}`);
  console.log(`   Account : ${process.env.HEDERA_ACCOUNT_ID ?? "⚠ not configured"}`);
  console.log(`   API     : http://localhost:${PORT}/api`);
  if (process.env.NODE_ENV !== "production") {
    console.log(`   Frontend: http://localhost:5173 (Vite dev server)\n`);
  }
});

export default app;
