// src/types.ts
// ── Shared types across the policy agent ───────────────────────────────────

export type Currency = "HBAR" | "USDC";

export type PolicyDecision = "approved" | "blocked" | "needs_approval";

export interface PolicyViolation {
  policy: "spend_limit" | "allowlist" | "approval_threshold" | "anomaly";
  reason: string;
  detail?: string;
}

export interface TransferRequest {
  /** Destination Hedera account (e.g. "0.0.1234567") */
  toAccountId: string;
  amount: number;
  currency: Currency;
  /** Human-readable purpose / memo */
  memo?: string;
  /** Service name if known (e.g. "OpenAI API") */
  serviceName?: string;
  /** Originating agent message for audit log */
  rawIntent: string;
}

export interface PolicyResult {
  decision: PolicyDecision;
  violations: PolicyViolation[];
  /** Explanation surfaced to the user */
  message: string;
}

export interface ExecutedTransaction {
  id: string;
  request: TransferRequest;
  decision: PolicyDecision;
  txHash?: string;
  timestamp: string;
  violations: PolicyViolation[];
}

export interface SpendState {
  hbar: number;
  usdc: number;
  /** ISO date string of when the window started (24h rolling) */
  windowStart: string;
}

export interface PolicyConfig {
  spendLimit: {
    enabled: boolean;
    hbar: number;
    usdc: number;
  };
  allowlist: {
    enabled: boolean;
    accounts: string[];
  };
  approvalThreshold: {
    enabled: boolean;
    hbar: number;
  };
  anomalyDetection: {
    enabled: boolean;
  };
}

export interface AgentMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface ChatRequest {
  message: string;
  conversationId: string;
  policyConfig?: Partial<PolicyConfig>;
}

export interface ChatResponse {
  response: string;
  policyResult?: PolicyResult;
  transaction?: ExecutedTransaction;
  spendState: SpendState;
}
