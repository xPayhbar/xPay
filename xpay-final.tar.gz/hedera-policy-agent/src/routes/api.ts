// src/routes/api.ts
// REST API — wires the LangGraph agent + policy engine to the frontend

import { Router }                                        from "express";
import { createxPay, getPendingApprovals }        from "../agent.js";
import { DEFAULT_POLICY_CONFIG }                         from "../policyEngine.js";
import { getSpendState, resetSpendState }                from "../hooks/spendLimitHook.js";
import { executeTransfer }                               from "../hederaClient.js";
import type { ChatRequest, PolicyConfig }                from "../types.js";

const router = Router();

// ── Per-conversation agent instances (keyed by conversationId) ─────────────
const agents = new Map<string, ReturnType<typeof createxPay>>();

function getOrCreateAgent(id: string, overrides?: Partial<PolicyConfig>) {
  if (!agents.has(id)) {
    const cfg: PolicyConfig = {
      ...DEFAULT_POLICY_CONFIG,
      ...overrides,
      spendLimit:        { ...DEFAULT_POLICY_CONFIG.spendLimit,        ...(overrides?.spendLimit        ?? {}) },
      allowlist:         { ...DEFAULT_POLICY_CONFIG.allowlist,         ...(overrides?.allowlist         ?? {}) },
      approvalThreshold: { ...DEFAULT_POLICY_CONFIG.approvalThreshold, ...(overrides?.approvalThreshold ?? {}) },
      anomalyDetection:  { ...DEFAULT_POLICY_CONFIG.anomalyDetection,  ...(overrides?.anomalyDetection  ?? {}) },
    };
    agents.set(id, createXPayAgent(cfg));
  }
  return agents.get(id)!;
}

// ── POST /api/chat ─────────────────────────────────────────────────────────
router.post("/chat", async (req, res) => {
  const { message, conversationId, policyConfig }: ChatRequest = req.body;
  if (!message || !conversationId)
    return res.status(400).json({ error: "message and conversationId are required" });

  try {
    const agent  = getOrCreateAgent(conversationId, policyConfig);
    const result = await agent.invoke(
      { messages: [{ role: "user", content: message }] },
      { configurable: { thread_id: conversationId } }
    );

    const last    = result.messages[result.messages.length - 1];
    const content = typeof last.content === "string"
      ? last.content
      : JSON.stringify(last.content);

    // Extract any policy/transaction signals from tool output in message list
    let policyResult  = null;
    let transaction   = null;

    for (const msg of result.messages) {
      if (msg._getType?.() === "tool") {
        try {
          const parsed = JSON.parse(
            typeof msg.content === "string" ? msg.content : JSON.stringify(msg.content)
          );
          if (parsed.status === "SUCCESS" || parsed.status === "BLOCKED" || parsed.status === "NEEDS_APPROVAL") {
            transaction = {
              id: `tx-${Date.now()}`,
              request: {
                toAccountId: parsed.toAccountId ?? "unknown",
                amount:      parsed.amount       ?? 0,
                currency:    parsed.currency     ?? "HBAR",
                serviceName: parsed.serviceName  ?? null,
              },
              decision: parsed.status === "SUCCESS" ? "approved" : parsed.status === "NEEDS_APPROVAL" ? "needs_approval" : "blocked",
              txHash:    parsed.txHash ?? null,
              timestamp: new Date().toISOString(),
              violations: [],
            };
            policyResult = {
              decision: transaction.decision,
              violations: [],
              message: content,
              // Surface which policy triggered (parsed from error message if available)
              policyTriggered: parsed.policyTriggered ?? null,
            };
          }
        } catch { /* non-JSON tool output, skip */ }
      }
    }

    return res.json({ response: content, policyResult, transaction, spendState: getSpendState() });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return res.status(500).json({ error: msg });
  }
});

// ── GET /api/spend ─────────────────────────────────────────────────────────
router.get("/spend", (_req, res) => res.json(getSpendState()));

// ── POST /api/spend/reset ──────────────────────────────────────────────────
router.post("/spend/reset", (_req, res) => {
  resetSpendState();
  res.json({ ok: true, spendState: getSpendState() });
});

// ── GET /api/pending ──────────────────────────────────────────────────────
router.get("/pending", (_req, res) => {
  const pending = Object.fromEntries(getPendingApprovals());
  res.json({ pending });
});

// ── POST /api/approve/:pendingId ──────────────────────────────────────────
// Used when the frontend falls back to server-side signing
// (no wallet connected). When wallet is connected, the frontend
// signs the transaction itself and just calls this to record the result.
router.post("/approve/:pendingId", async (req, res) => {
  const pending = getPendingApprovals();
  const request = pending.get(req.params.pendingId);
  if (!request) return res.status(404).json({ error: "Pending transaction not found" });

  // If the client already signed + submitted with wallet, they pass the txHash
  const { walletTxHash } = req.body ?? {};

  if (walletTxHash) {
    // Wallet-signed: just record spend and return
    pending.delete(req.params.pendingId);
    return res.json({ ok: true, transaction: { ...request, txHash: walletTxHash }, spendState: getSpendState() });
  }

  // Server keypair fallback
  try {
    const tx = await executeTransfer(request);
    pending.delete(req.params.pendingId);
    return res.json({ ok: true, transaction: tx, spendState: getSpendState() });
  } catch (err: unknown) {
    return res.status(500).json({ error: err instanceof Error ? err.message : "Transfer failed" });
  }
});

// ── POST /api/reject/:pendingId ───────────────────────────────────────────
router.post("/reject/:pendingId", (req, res) => {
  const pending = getPendingApprovals();
  if (!pending.has(req.params.pendingId))
    return res.status(404).json({ error: "Pending transaction not found" });
  const request = pending.get(req.params.pendingId)!;
  pending.delete(req.params.pendingId);
  return res.json({ ok: true, rejected: request });
});

// ── GET /api/policy ───────────────────────────────────────────────────────
router.get("/policy", (_req, res) => res.json(DEFAULT_POLICY_CONFIG));

// ── GET /api/health ───────────────────────────────────────────────────────
router.get("/health", (_req, res) =>
  res.json({
    status:    "ok",
    network:   process.env.HEDERA_NETWORK ?? "testnet",
    account:   process.env.HEDERA_ACCOUNT_ID ?? "not configured",
    walletConnect: true,
    agentKitVersion: "v4",
    timestamp: new Date().toISOString(),
  })
);

export default router;
