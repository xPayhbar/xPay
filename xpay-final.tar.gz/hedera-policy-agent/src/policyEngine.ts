// src/policyEngine.ts
// V3 policy engine — plain TypeScript, runs BEFORE the toolkit executes anything.
// (V4 AbstractPolicy / BaseTool are not yet published to npm as of June 2026)

import type { TransferRequest, PolicyResult, PolicyViolation, PolicyConfig } from "./types.js";
import { getSpendState } from "./hooks/spendLimitHook.js";
import { KNOWN_SERVICES } from "./hooks/allowlistHook.js";

export const DEFAULT_POLICY_CONFIG: PolicyConfig = {
  spendLimit: {
    enabled: true,
    hbar:    Number(process.env.POLICY_SPEND_LIMIT_HBAR    ?? 500),
    usdc:    Number(process.env.POLICY_SPEND_LIMIT_USDC    ?? 100),
  },
  allowlist: {
    enabled:  true,
    accounts: (process.env.POLICY_ALLOWED_ACCOUNTS ?? "").split(",").filter(Boolean),
  },
  approvalThreshold: {
    enabled: true,
    hbar:    Number(process.env.POLICY_APPROVAL_THRESHOLD_HBAR ?? 100),
  },
  anomalyDetection: { enabled: true },
};

// ── Hook 1: Allowlist ──────────────────────────────────────────────────────
function checkAllowlist(req: TransferRequest, cfg: PolicyConfig): PolicyViolation | null {
  if (!cfg.allowlist.enabled || cfg.allowlist.accounts.length === 0) return null;
  const ok = cfg.allowlist.accounts
    .some(a => a.trim().toLowerCase() === req.toAccountId.trim().toLowerCase());
  return ok ? null : {
    policy: "allowlist",
    reason: `Account ${req.toAccountId} is not on the approved counterparty list`,
  };
}

// ── Hook 2: Anomaly ────────────────────────────────────────────────────────
function checkAnomaly(req: TransferRequest, cfg: PolicyConfig): PolicyViolation | null {
  if (!cfg.anomalyDetection.enabled) return null;

  if (!KNOWN_SERVICES[req.toAccountId.trim()])
    return { policy: "anomaly", reason: `Unknown recipient: ${req.toAccountId}` };

  const max = req.currency === "HBAR" ? 10_000 : 5_000;
  if (req.amount > max)
    return { policy: "anomaly", reason: `Amount ${req.amount} ${req.currency} exceeds plausible maximum` };

  if (req.amount >= 1000 && req.amount % 1000 === 0)
    return { policy: "anomaly", reason: `Suspicious round amount: ${req.amount} ${req.currency}` };

  return null;
}

// ── Hook 3: Approval threshold ────────────────────────────────────────────
function checkApproval(req: TransferRequest, cfg: PolicyConfig): PolicyViolation | null {
  if (!cfg.approvalThreshold.enabled) return null;
  if (req.currency !== "HBAR") return null;
  if (req.amount >= cfg.approvalThreshold.hbar)
    return { policy: "approval_threshold", reason: `${req.amount} HBAR ≥ threshold (${cfg.approvalThreshold.hbar} HBAR)` };
  return null;
}

// ── Hook 4: Spend limit ────────────────────────────────────────────────────
function checkSpendLimit(req: TransferRequest, cfg: PolicyConfig): PolicyViolation | null {
  if (!cfg.spendLimit.enabled) return null;
  const state = getSpendState();
  const used  = req.currency === "HBAR" ? state.hbar : state.usdc;
  const limit = req.currency === "HBAR" ? cfg.spendLimit.hbar : cfg.spendLimit.usdc;
  if (used + req.amount > limit)
    return { policy: "spend_limit", reason: `Daily limit ${limit} ${req.currency} — used ${used.toFixed(2)}, requested ${req.amount}` };
  return null;
}

// ── Engine: run all hooks ──────────────────────────────────────────────────
export function evaluatePolicy(
  request: TransferRequest,
  config: PolicyConfig = DEFAULT_POLICY_CONFIG
): PolicyResult {
  const violations: PolicyViolation[] = [
    checkAllowlist(request, config),
    checkAnomaly(request, config),
    checkApproval(request, config),
    checkSpendLimit(request, config),
  ].filter((v): v is PolicyViolation => v !== null);

  if (violations.length === 0)
    return { decision: "approved", violations: [], message: `✓ All policies passed.` };

  const hardBlock = violations.some(v => v.policy === "spend_limit" || v.policy === "allowlist");
  if (hardBlock)
    return { decision: "blocked", violations, message: `🚫 Blocked: ${violations.map(v => v.reason).join("; ")}` };

  return { decision: "needs_approval", violations, message: `⏳ Needs approval: ${violations.map(v => v.reason).join("; ")}` };
}
