// src/hooks/approvalHook.ts
// Policy Hook: High-value transactions require human-in-the-loop approval

import type { TransferRequest, PolicyViolation, PolicyConfig } from "../types.js";

/**
 * Approval Threshold Hook — flags transactions above the configured HBAR threshold.
 * USDC transfers are always auto-approved (adjust as needed for your use case).
 *
 * When this fires, the agent returns "needs_approval" instead of blocking outright —
 * a human can then explicitly approve or reject via the /api/approve endpoint.
 */
export function checkApprovalThreshold(
  request: TransferRequest,
  config: PolicyConfig
): PolicyViolation | null {
  if (!config.approvalThreshold.enabled) return null;
  // Only gate HBAR transfers for now; extend for USDC if needed
  if (request.currency !== "HBAR") return null;

  if (request.amount >= config.approvalThreshold.hbar) {
    return {
      policy: "approval_threshold",
      reason: `Transfer of ${request.amount} HBAR exceeds auto-approval threshold (${config.approvalThreshold.hbar} HBAR)`,
      detail: `This transaction requires explicit human approval before it can be executed.`,
    };
  }

  return null;
}
