// src/hooks/anomalyHook.ts
// Policy Hook: Lightweight anomaly detection — flags suspicious patterns

import type { TransferRequest, PolicyViolation, PolicyConfig } from "../types.js";
import { KNOWN_SERVICES } from "./allowlistHook.js";

/** Rough upper bound for a "plausible" single API service payment */
const MAX_PLAUSIBLE_SINGLE_PAYMENT_HBAR = 10_000;
const MAX_PLAUSIBLE_SINGLE_PAYMENT_USDC = 5_000;

/**
 * Anomaly Detection Hook — heuristic checks for suspicious transfer patterns.
 * Returns a PolicyViolation if something looks off, null otherwise.
 */
export function checkAnomaly(
  request: TransferRequest,
  config: PolicyConfig
): PolicyViolation | null {
  if (!config.anomalyDetection.enabled) return null;

  // 1. Unknown recipient (not in known services map)
  const isKnownService = Boolean(KNOWN_SERVICES[request.toAccountId.trim()]);
  if (!isKnownService) {
    return {
      policy: "anomaly",
      reason: "Unknown recipient — not in known-services registry",
      detail: `Account ${request.toAccountId} has no service record. Verify the recipient before proceeding.`,
    };
  }

  // 2. Absurdly large single payment
  const maxPlausible =
    request.currency === "HBAR"
      ? MAX_PLAUSIBLE_SINGLE_PAYMENT_HBAR
      : MAX_PLAUSIBLE_SINGLE_PAYMENT_USDC;

  if (request.amount > maxPlausible) {
    return {
      policy: "anomaly",
      reason: `Unusually large payment (${request.amount} ${request.currency})`,
      detail: `Single payments above ${maxPlausible} ${request.currency} are flagged for review.`,
    };
  }

  // 3. Round-number suspicion (very large round numbers are common in fraud)
  if (request.amount >= 1000 && request.amount % 1000 === 0) {
    return {
      policy: "anomaly",
      reason: `Suspiciously round amount (${request.amount} ${request.currency})`,
      detail: `Large round-number payments are flagged. Confirm this is intentional.`,
    };
  }

  return null;
}
