// src/hooks/allowlistHook.ts
// Policy Hook: Counterparty allowlist — only pay pre-approved Hedera accounts

import type { TransferRequest, PolicyViolation, PolicyConfig } from "../types.js";

/**
 * Allowlist Hook — validates the destination account is on the approved list.
 * Returns a PolicyViolation if the account is not approved, or null if it passes.
 */
export function checkAllowlist(
  request: TransferRequest,
  config: PolicyConfig
): PolicyViolation | null {
  if (!config.allowlist.enabled) return null;
  if (config.allowlist.accounts.length === 0) return null;

  const normalised = request.toAccountId.trim().toLowerCase();
  const isAllowed = config.allowlist.accounts.some(
    (a) => a.trim().toLowerCase() === normalised
  );

  if (!isAllowed) {
    return {
      policy: "allowlist",
      reason: `Counterparty not in allowlist`,
      detail: `Account ${request.toAccountId} is not an approved recipient. Approved: ${config.allowlist.accounts.join(", ")}`,
    };
  }

  return null;
}

/** Utility — look up a friendly service name for an account ID */
export const KNOWN_SERVICES: Record<string, string> = {
  "0.0.4567890": "OpenAI API",
  "0.0.8901234": "Pinecone DB",
  "0.0.2345678": "Twilio SMS",
  "0.0.3456789": "IPFS Storage",
  "0.0.6789012": "TheGraph API",
  "0.0.5432100": "Chainlink Oracle",
  "0.0.7654321": "Filecoin Archive",
};

export function resolveServiceName(accountId: string): string | undefined {
  return KNOWN_SERVICES[accountId.trim()];
}
