// src/hooks/spendLimitHook.ts
// Policy Hook: Daily spend cap enforcement (HBAR and USDC)

import type { TransferRequest, PolicyViolation, SpendState, PolicyConfig } from "../types.js";

/** In-memory rolling 24-hour spend tracker.
 *  In production, back this with Redis or a DB. */
let state: SpendState = {
  hbar: 0,
  usdc: 0,
  windowStart: new Date().toISOString(),
};

/** Reset spend window if it's older than 24 hours */
function ensureFreshWindow(): void {
  const windowAgeMs = Date.now() - new Date(state.windowStart).getTime();
  if (windowAgeMs >= 24 * 60 * 60 * 1000) {
    state = { hbar: 0, usdc: 0, windowStart: new Date().toISOString() };
  }
}

export function getSpendState(): SpendState {
  ensureFreshWindow();
  return { ...state };
}

export function recordSpend(amount: number, currency: "HBAR" | "USDC"): void {
  ensureFreshWindow();
  if (currency === "HBAR") {
    state.hbar += amount;
  } else {
    state.usdc += amount;
  }
}

export function resetSpendState(): void {
  state = { hbar: 0, usdc: 0, windowStart: new Date().toISOString() };
}

/**
 * Spend Limit Hook — runs BEFORE a transfer executes.
 * Returns a PolicyViolation if the transfer would exceed the cap,
 * or null if it passes.
 */
export function checkSpendLimit(
  request: TransferRequest,
  config: PolicyConfig
): PolicyViolation | null {
  if (!config.spendLimit.enabled) return null;

  ensureFreshWindow();

  const limit =
    request.currency === "HBAR" ? config.spendLimit.hbar : config.spendLimit.usdc;
  const current = request.currency === "HBAR" ? state.hbar : state.usdc;
  const afterTransfer = current + request.amount;

  if (afterTransfer > limit) {
    return {
      policy: "spend_limit",
      reason: `Daily ${request.currency} spend limit exceeded`,
      detail: `Limit: ${limit} ${request.currency} | Used: ${current.toFixed(2)} | Requested: ${request.amount} | Would reach: ${afterTransfer.toFixed(2)}`,
    };
  }

  return null;
}
